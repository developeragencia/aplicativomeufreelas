# 99Freelas Profile Edit - Technical Specification

## 1. Tech Stack Overview

| Category | Technology |
|----------|------------|
| Framework | React 18 + TypeScript |
| Build Tool | Vite |
| Styling | Tailwind CSS 3.4 |
| UI Components | shadcn/ui |
| Form Handling | React Hook Form + Zod |
| Animations | Framer Motion |
| Icons | Lucide React |

## 2. Tailwind Configuration Extensions

```javascript
// tailwind.config.js extensions
{
  theme: {
    extend: {
      colors: {
        primary: '#00A8E8',
        'primary-dark': '#0095D1',
        success: '#5CB85C',
        'success-hover': '#4CA84C',
        danger: '#D9534F',
        'danger-hover': '#C9433F',
        surface: '#FFFFFF',
        background: '#F5F5F5',
        'text-primary': '#333333',
        'text-secondary': '#666666',
        'text-muted': '#999999',
        border: '#DDDDDD',
        'info-bg': '#E3F2FD',
        'info-text': '#1976D2',
      },
      fontFamily: {
        sans: ['Arial', 'sans-serif'],
      },
      boxShadow: {
        'input-focus': '0 0 0 3px rgba(0,168,232,0.1)',
        'help-button': '0 4px 12px rgba(0,0,0,0.15)',
      },
    },
  },
}
```

## 3. Component Inventory

### Shadcn/UI Components (Pre-installed)
- Button
- Input
- Textarea
- Accordion
- Label
- Card
- Avatar
- Tooltip
- Badge

### Custom Components

| Component | Props | Description |
|-----------|-------|-------------|
| Header | - | Main navigation header |
| ProfileForm | onSubmit: (data) => void | Main profile edit form |
| ProfilePicture | imageUrl?: string | Profile picture upload card |
| FormInput | label, name, type, placeholder, helperText | Reusable input field |
| FormTextarea | label, name, placeholder, helperText, maxLength | Reusable textarea |
| InterestAccordion | items: InterestItem[] | Expandable interest categories |
| HelpButton | - | Floating help button |
| WarningMessage | children | Warning message with icon |

### Types

```typescript
interface ProfileFormData {
  fullName: string;
  nickname: string;
  professionalTitle: string;
  aboutYou: string;
  experience: string;
  skills: string[];
  interests: string[];
}

interface InterestItem {
  id: string;
  label: string;
  subItems?: string[];
}
```

## 4. Animation Implementation Plan

| Interaction | Tech Choice | Implementation |
|-------------|-------------|----------------|
| Page Load Fade | Framer Motion | `initial={{ opacity: 0, y: 20 }}` `animate={{ opacity: 1, y: 0 }}` duration: 0.5s |
| Input Focus | Tailwind | `transition-all duration-200 focus:border-primary focus:shadow-input-focus` |
| Button Hover | Tailwind + Framer | `whileHover={{ scale: 1.02 }}` `whileTap={{ scale: 0.98 }}` |
| Accordion Expand | Framer Motion | `AnimatePresence` with height animation, duration: 0.3s |
| Help Button | Framer Motion | `whileHover={{ scale: 1.1 }}` `whileTap={{ scale: 0.95 }}` |
| Save Success | Framer Motion | Scale pulse + opacity fade, duration: 0.3s |
| Form Validation | Framer Motion | Shake animation on error, x: [-5, 5, -5, 5, 0] |

### Animation Timing Constants

```typescript
const ANIMATION = {
  duration: {
    fast: 0.15,
    normal: 0.3,
    slow: 0.5,
  },
  easing: {
    default: [0.4, 0, 0.2, 1],
    bounce: [0.68, -0.55, 0.265, 1.55],
  },
};
```

## 5. Project File Structure

```
/mnt/okcomputer/output/app/
├── src/
│   ├── components/
│   │   ├── ui/           # shadcn/ui components
│   │   ├── Header.tsx
│   │   ├── ProfileForm.tsx
│   │   ├── ProfilePicture.tsx
│   │   ├── FormInput.tsx
│   │   ├── FormTextarea.tsx
│   │   ├── InterestAccordion.tsx
│   │   ├── HelpButton.tsx
│   │   └── WarningMessage.tsx
│   ├── hooks/
│   │   └── useProfileForm.ts
│   ├── types/
│   │   └── index.ts
│   ├── lib/
│   │   └── utils.ts
│   ├── App.tsx
│   ├── App.css
│   └── main.tsx
├── public/
├── index.html
├── tailwind.config.js
├── vite.config.ts
└── package.json
```

## 6. Package Installation Commands

```bash
# Initialize project
bash /app/.kimi/skills/webapp-building/scripts/init-webapp.sh "99Freelas Profile Edit"

# Install additional dependencies
cd /mnt/okcomputer/output/app
npm install framer-motion react-hook-form zod @hookform/resolvers lucide-react

# Add shadcn components
npx shadcn add accordion avatar badge card label textarea tooltip
```

## 7. Form Validation Schema (Zod)

```typescript
const profileSchema = z.object({
  fullName: z.string().min(2, 'Nome completo é obrigatório'),
  nickname: z.string().min(2, 'Nickname é obrigatório'),
  professionalTitle: z.string().optional(),
  aboutYou: z.string().max(2000, 'Máximo 2000 caracteres').optional(),
  experience: z.string().max(2000, 'Máximo 2000 caracteres').optional(),
  skills: z.array(z.string()).optional(),
  interests: z.array(z.string()).optional(),
});
```

## 8. Key Implementation Notes

1. **Form State Management**: Use React Hook Form with Zod validation
2. **Accordion Behavior**: Only one item expanded at a time
3. **Character Counters**: Show current/max for textareas
4. **Responsive Layout**: CSS Grid with breakpoint at 1024px
5. **Accessibility**: Proper ARIA labels, keyboard navigation
6. **Performance**: Memoize form components to prevent unnecessary re-renders
