import { useState, useRef } from 'react';
import { Camera } from 'lucide-react';

interface ProfilePictureProps {
  imageUrl?: string;
  userName?: string;
}

export default function ProfilePicture({ imageUrl, userName = 'H' }: ProfilePictureProps) {
  const [preview, setPreview] = useState<string | null>(imageUrl || null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setPreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleClick = () => {
    fileInputRef.current?.click();
  };

  return (
    <div className="bg-white border border-[#ddd] rounded-sm p-5 w-[260px]">
      {/* Profile Picture Placeholder */}
      <div className="flex flex-col items-center">
        <div
          className="relative w-[140px] h-[140px] bg-[#5CB85C] flex items-center justify-center overflow-hidden cursor-pointer hover:opacity-90 transition-opacity"
          onClick={handleClick}
        >
          {preview ? (
            <img
              src={preview}
              alt="Profile"
              className="w-full h-full object-cover"
            />
          ) : (
            <span className="text-white text-[72px] font-normal select-none">
              {userName.charAt(0).toUpperCase()}
            </span>
          )}
          
          {/* Overlay on hover */}
          <div className="absolute inset-0 bg-black/30 opacity-0 hover:opacity-100 transition-opacity flex items-center justify-center">
            <Camera className="w-8 h-8 text-white" />
          </div>
        </div>

        {/* Info Text */}
        <p className="mt-4 text-[12px] text-[#666] text-center leading-[1.5]">
          Adicione uma foto para que os clientes possam conhecê-lo melhor. A foto deve ser de rosto e sem óculos escuros.
        </p>

        {/* Add Photo Button */}
        <button
          onClick={handleClick}
          className="mt-4 w-full bg-[#D9534F] hover:bg-[#C9302C] text-white text-[14px] font-normal py-2.5 px-4 rounded-sm transition-colors"
        >
          Adicionar Foto
        </button>

        <input
          ref={fileInputRef}
          type="file"
          accept="image/*"
          onChange={handleFileChange}
          className="hidden"
        />
      </div>
    </div>
  );
}
