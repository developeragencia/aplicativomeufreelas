import { AlertTriangle } from 'lucide-react';
import type { ReactNode } from 'react';

interface WarningMessageProps {
  children: ReactNode;
}

export default function WarningMessage({ children }: WarningMessageProps) {
  return (
    <div className="flex items-start gap-2 text-[#D9534F] mt-1">
      <AlertTriangle className="w-4 h-4 mt-0.5 flex-shrink-0" />
      <span className="text-[12px]">{children}</span>
    </div>
  );
}
