import { useState } from 'react';
import { ChevronRight, ChevronDown } from 'lucide-react';
import type { InterestItem } from '@/types';

interface InterestAccordionProps {
  items: InterestItem[];
  selectedInterests: string[];
  onInterestChange: (interest: string, checked: boolean) => void;
}

export default function InterestAccordion({
  items,
  selectedInterests,
  onInterestChange,
}: InterestAccordionProps) {
  const [expandedItems, setExpandedItems] = useState<string[]>([]);

  const toggleExpand = (itemId: string) => {
    setExpandedItems((prev) =>
      prev.includes(itemId)
        ? prev.filter((id) => id !== itemId)
        : [...prev, itemId]
    );
  };

  return (
    <div className="space-y-2">
      <label className="block text-[14px] font-bold text-[#333]">
        Áreas de Interesse
      </label>

      <div className="border border-[#ccc] rounded-sm overflow-hidden">
        {items.map((item, index) => {
          const isExpanded = expandedItems.includes(item.id);
          const isSelected = selectedInterests.includes(item.id);

          return (
            <div
              key={item.id}
              className={`border-b border-[#eee] last:border-b-0 ${
                index % 2 === 0 ? 'bg-white' : 'bg-[#f9f9f9]'
              }`}
            >
              {/* Header */}
              <div className="flex items-center px-3 py-2.5">
                <input
                  type="checkbox"
                  id={`interest-${item.id}`}
                  checked={isSelected}
                  onChange={(e) => onInterestChange(item.id, e.target.checked)}
                  className="w-4 h-4 mr-3 cursor-pointer accent-[#00A0D2]"
                />
                <label
                  htmlFor={`interest-${item.id}`}
                  className="flex-1 text-[13px] text-[#333] cursor-pointer"
                >
                  {item.label}
                </label>
                <button
                  type="button"
                  onClick={() => toggleExpand(item.id)}
                  className="p-1 hover:bg-gray-100 rounded transition-colors"
                >
                  {isExpanded ? (
                    <ChevronDown className="w-4 h-4 text-[#666]" />
                  ) : (
                    <ChevronRight className="w-4 h-4 text-[#666]" />
                  )}
                </button>
              </div>

              {/* Expanded Content */}
              {isExpanded && item.subItems && item.subItems.length > 0 && (
                <div className="pl-10 pr-3 pb-2 bg-white">
                  {item.subItems.map((subItem) => (
                    <div key={subItem} className="flex items-center py-1.5">
                      <input
                        type="checkbox"
                        id={`subitem-${subItem}`}
                        checked={selectedInterests.includes(subItem)}
                        onChange={(e) =>
                          onInterestChange(subItem, e.target.checked)
                        }
                        className="w-4 h-4 mr-3 cursor-pointer accent-[#00A0D2]"
                      />
                      <label
                        htmlFor={`subitem-${subItem}`}
                        className="text-[13px] text-[#666] cursor-pointer"
                      >
                        {subItem}
                      </label>
                    </div>
                  ))}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
