import type { FormInputProps } from '@/types';

export default function FormInput({
  label,
  name,
  type = 'text',
  placeholder,
  helperText,
  value,
  onChange,
  error,
}: FormInputProps) {
  return (
    <div className="space-y-1.5">
      <label
        htmlFor={name}
        className="block text-[14px] font-bold text-[#333]"
      >
        {label}
      </label>
      
      <input
        id={name}
        name={name}
        type={type}
        placeholder={placeholder}
        value={value}
        onChange={(e) => onChange?.(e.target.value)}
        className={`
          w-full px-3 py-2 border border-[#ccc] rounded-sm
          text-[14px] text-[#333] placeholder:text-[#999]
          focus:border-[#00A0D2] focus:outline-none focus:ring-1 focus:ring-[#00A0D2]/20
          ${error ? 'border-[#D9534F]' : ''}
        `}
      />
      
      {helperText && (
        <p className="text-[12px] text-[#666]">{helperText}</p>
      )}
      
      {error && (
        <p className="text-[12px] text-[#D9534F]">
          {error}
        </p>
      )}
    </div>
  );
}
