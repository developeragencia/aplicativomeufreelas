import { motion } from 'framer-motion';
import { Search, Bell, MessageSquare, User, ChevronDown, Menu } from 'lucide-react';
import { useState } from 'react';

const navItems = [
  'Meus projetos',
  'Projetos',
  'Freelancers',
  'Perfil',
  'Conta',
  'Como funciona',
  'Ajuda',
];

export default function Header() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <motion.header
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, ease: [0.4, 0, 0.2, 1] }}
      className="fixed top-0 left-0 right-0 z-50 bg-[#0099CC] h-[60px]"
    >
      <div className="max-w-[1200px] mx-auto h-full px-4 flex items-center justify-between">
        {/* Logo e Nav */}
        <div className="flex items-center">
          {/* Logo */}
          <a href="/" className="flex items-center mr-6">
            <span className="text-white text-xl font-bold">
              <span className="italic font-serif">99</span>
              <span className="font-sans">freelas</span>
            </span>
          </a>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center">
            {navItems.map((item) => (
              <a
                key={item}
                href="#"
                className="text-white text-[13px] px-3 py-2 hover:bg-white/10 transition-colors"
              >
                {item}
              </a>
            ))}
          </nav>
        </div>

        {/* Search e Icons */}
        <div className="flex items-center gap-3">
          {/* Search Bar */}
          <div className="hidden md:flex items-center bg-white rounded-sm h-[32px] w-[180px]">
            <input
              type="text"
              placeholder="Buscar projetos"
              className="flex-1 text-[13px] outline-none text-[#333] placeholder:text-[#999] px-3 h-full bg-transparent"
            />
            <button className="px-2 h-full flex items-center justify-center">
              <Search className="w-4 h-4 text-[#666]" />
            </button>
          </div>

          {/* Icons */}
          <div className="flex items-center gap-1">
            <button className="p-2 text-white hover:bg-white/10 transition-colors">
              <Bell className="w-5 h-5" />
            </button>
            <button className="p-2 text-white hover:bg-white/10 transition-colors">
              <MessageSquare className="w-5 h-5" />
            </button>
            <button className="flex items-center gap-1 p-2 text-white hover:bg-white/10 transition-colors">
              <div className="w-7 h-7 bg-white/20 rounded-full flex items-center justify-center">
                <User className="w-4 h-4" />
              </div>
              <ChevronDown className="w-4 h-4" />
            </button>
          </div>

          {/* Mobile Menu Button */}
          <button
            className="lg:hidden p-2 text-white hover:bg-white/10 transition-colors"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            <Menu className="w-6 h-6" />
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {mobileMenuOpen && (
        <motion.div
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: 'auto' }}
          exit={{ opacity: 0, height: 0 }}
          className="lg:hidden bg-[#0077AA] border-t border-white/10"
        >
          <nav className="flex flex-col p-4">
            {navItems.map((item) => (
              <a
                key={item}
                href="#"
                className="text-white text-[13px] py-2 px-3 hover:bg-white/10"
              >
                {item}
              </a>
            ))}
          </nav>
        </motion.div>
      )}
    </motion.header>
  );
}
