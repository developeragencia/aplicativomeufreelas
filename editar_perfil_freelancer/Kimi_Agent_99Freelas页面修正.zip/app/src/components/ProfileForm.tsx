import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Check, Plus, X } from 'lucide-react';
import FormInput from './FormInput';
import FormTextarea from './FormTextarea';
import WarningMessage from './WarningMessage';
import InterestAccordion from './InterestAccordion';
import type { InterestItem } from '@/types';

// Validation schema
const profileSchema = z.object({
  fullName: z.string().min(2, 'Nome completo é obrigatório'),
  nickname: z.string().min(2, 'Nickname é obrigatório'),
  professionalTitle: z.string().optional(),
  aboutYou: z.string().max(2000, 'Máximo 2000 caracteres').optional(),
  experience: z.string().max(2000, 'Máximo 2000 caracteres').optional(),
});

type ProfileFormData = z.infer<typeof profileSchema>;

// Interest items data
const interestItems: InterestItem[] = [
  { id: 'administracao', label: 'Administração e Consultoria' },
  { id: 'advocacia', label: 'Advocacia e Lei' },
  { id: 'arquitetura', label: 'Arquitetura e Engenharia' },
  { id: 'design', label: 'Design e Criação' },
  { id: 'educacao', label: 'Educação e Consultoria' },
  { id: 'engenharia', label: 'Engenharia e Arquitetura' },
  { id: 'eventos', label: 'Eventos' },
  { id: 'fotografia', label: 'Fotografia e Audiovisual' },
  { id: 'traducao', label: 'Tradução e Interpretação' },
  { id: 'traducao-only', label: 'Tradução' },
  { id: 'vendas', label: 'Vendas e Marketing' },
  { id: 'web', label: 'Web, Mobile e Software' },
];

export default function ProfileForm() {
  const [selectedInterests, setSelectedInterests] = useState<string[]>([]);
  const [skills, setSkills] = useState<string[]>([]);
  const [skillInput, setSkillInput] = useState('');
  const [isSaved, setIsSaved] = useState(false);

  const {
    handleSubmit,
    formState: { errors },
    watch,
    setValue,
  } = useForm<ProfileFormData>({
    resolver: zodResolver(profileSchema),
    defaultValues: {
      fullName: 'Hugo Calsavara',
      nickname: 'hugo-calsavara',
      professionalTitle: '',
      aboutYou: '',
      experience: '',
    },
  });

  const handleInterestChange = (interest: string, checked: boolean) => {
    setSelectedInterests((prev) =>
      checked ? [...prev, interest] : prev.filter((i) => i !== interest)
    );
  };

  const handleAddSkill = () => {
    if (skillInput.trim() && !skills.includes(skillInput.trim())) {
      setSkills([...skills, skillInput.trim()]);
      setSkillInput('');
    }
  };

  const handleRemoveSkill = (skillToRemove: string) => {
    setSkills(skills.filter((skill) => skill !== skillToRemove));
  };

  const handleSkillKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      handleAddSkill();
    }
  };

  const onSubmit = (data: ProfileFormData) => {
    console.log('Form submitted:', { ...data, interests: selectedInterests, skills });
    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 3000);
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
      {/* Page Title */}
      <h1 className="text-[24px] font-bold text-[#333] mb-6">
        Seu Perfil
      </h1>

      {/* Full Name */}
      <FormInput
        label="Nome completo"
        name="fullName"
        placeholder=""
        value={watch('fullName')}
        onChange={(value) => setValue('fullName', value)}
        error={errors.fullName?.message}
      />

      {/* Nickname */}
      <FormInput
        label="Nickname"
        name="nickname"
        placeholder=""
        helperText="Você só pode alterar o nickname uma vez"
        value={watch('nickname')}
        onChange={(value) => setValue('nickname', value)}
        error={errors.nickname?.message}
      />

      {/* Professional Title */}
      <FormInput
        label="Título profissional"
        name="professionalTitle"
        placeholder=""
        value={watch('professionalTitle')}
        onChange={(value) => setValue('professionalTitle', value)}
      />

      {/* About You */}
      <div className="space-y-1">
        <FormTextarea
          label="Conte-nos sobre você"
          name="aboutYou"
          placeholder=""
          maxLength={2000}
          value={watch('aboutYou')}
          onChange={(value) => setValue('aboutYou', value)}
        />
        <WarningMessage>
          Atenção: Não informe suas informações de contato ou links externos.
        </WarningMessage>
      </div>

      {/* Professional Experience */}
      <div className="space-y-1">
        <FormTextarea
          label="Resuma a sua experiência profissional"
          name="experience"
          placeholder=""
          maxLength={2000}
          value={watch('experience')}
          onChange={(value) => setValue('experience', value)}
        />
        <WarningMessage>
          Atenção: Não informe suas informações de contato ou links externos.
        </WarningMessage>
      </div>

      {/* Areas of Interest */}
      <InterestAccordion
        items={interestItems}
        selectedInterests={selectedInterests}
        onInterestChange={handleInterestChange}
      />

      {/* Skills */}
      <div className="space-y-2">
        <label className="block text-[14px] font-bold text-[#333]">
          Habilidades
        </label>
        
        <div className="flex gap-2">
          <input
            type="text"
            value={skillInput}
            onChange={(e) => setSkillInput(e.target.value)}
            onKeyDown={handleSkillKeyDown}
            placeholder=""
            className="flex-1 px-3 py-2 border border-[#ccc] rounded-sm text-[14px] text-[#333] placeholder:text-[#999] focus:border-[#00A0D2] focus:outline-none focus:ring-1 focus:ring-[#00A0D2]/20"
          />
          <button
            type="button"
            onClick={handleAddSkill}
            className="px-3 py-2 bg-[#00A0D2] hover:bg-[#008BB8] text-white rounded-sm transition-colors"
          >
            <Plus className="w-5 h-5" />
          </button>
        </div>

        {/* Skills Tags */}
        {skills.length > 0 && (
          <div className="flex flex-wrap gap-2 mt-2">
            {skills.map((skill) => (
              <span
                key={skill}
                className="inline-flex items-center gap-1 px-2 py-1 bg-[#E3F2FD] text-[#1976D2] text-[12px] rounded-sm"
              >
                {skill}
                <button
                  type="button"
                  onClick={() => handleRemoveSkill(skill)}
                  className="hover:text-[#D9534F] transition-colors"
                >
                  <X className="w-3 h-3" />
                </button>
              </span>
            ))}
          </div>
        )}
      </div>

      {/* Save Button */}
      <div className="pt-4">
        <button
          type="submit"
          className={`
            px-5 py-2.5 rounded-sm font-normal text-[14px] text-white transition-colors
            ${isSaved ? 'bg-[#5CB85C]' : 'bg-[#5CB85C] hover:bg-[#4CA84C]'}
          `}
        >
          {isSaved ? (
            <span className="flex items-center gap-2">
              <Check className="w-4 h-4" />
              Salvo com sucesso!
            </span>
          ) : (
            'Salvar Alterações'
          )}
        </button>
      </div>
    </form>
  );
}
