import { HelpCircle } from 'lucide-react';

export default function HelpButton() {
  return (
    <button
      className="fixed bottom-5 right-5 w-[50px] h-[50px] bg-[#00A0D2] hover:bg-[#008BB8] rounded-full flex items-center justify-center shadow-lg z-50 transition-colors"
      title="Ajuda"
    >
      <HelpCircle className="w-6 h-6 text-white" />
    </button>
  );
}
