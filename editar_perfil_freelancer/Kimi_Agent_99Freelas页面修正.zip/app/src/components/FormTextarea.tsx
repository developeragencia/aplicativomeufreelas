import { useState } from 'react';
import type { FormTextareaProps } from '@/types';

export default function FormTextarea({
  label,
  name,
  placeholder,
  helperText,
  maxLength = 2000,
  value = '',
  onChange,
  error,
}: FormTextareaProps) {
  const [charCount, setCharCount] = useState(value.length);

  const handleChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const newValue = e.target.value;
    if (maxLength && newValue.length > maxLength) return;
    
    setCharCount(newValue.length);
    onChange?.(newValue);
  };

  return (
    <div className="space-y-1.5">
      <label
        htmlFor={name}
        className="block text-[14px] font-bold text-[#333]"
      >
        {label}
      </label>
      
      <textarea
        id={name}
        name={name}
        placeholder={placeholder}
        value={value}
        onChange={handleChange}
        rows={5}
        className={`
          w-full px-3 py-2 border border-[#ccc] rounded-sm
          text-[14px] text-[#333] placeholder:text-[#999]
          resize-y min-h-[120px]
          focus:border-[#00A0D2] focus:outline-none focus:ring-1 focus:ring-[#00A0D2]/20
          ${error ? 'border-[#D9534F]' : ''}
        `}
      />
      
      <div className="flex items-center justify-between">
        {helperText && (
          <p className="text-[12px] text-[#666]">{helperText}</p>
        )}
        
        {maxLength && (
          <span className="text-[12px] text-[#999] ml-auto">
            {charCount}/{maxLength}
          </span>
        )}
      </div>
      
      {error && (
        <p className="text-[12px] text-[#D9534F]">
          {error}
        </p>
      )}
    </div>
  );
}
