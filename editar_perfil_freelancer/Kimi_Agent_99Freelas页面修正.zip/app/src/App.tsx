import Header from './components/Header';
import ProfileForm from './components/ProfileForm';
import ProfilePicture from './components/ProfilePicture';
import HelpButton from './components/HelpButton';
import './App.css';

function App() {
  return (
    <div className="min-h-screen bg-[#F5F5F5]">
      {/* Header */}
      <Header />

      {/* Main Content */}
      <main className="pt-[60px]">
        <div className="max-w-[1000px] mx-auto px-4 py-6">
          <div className="bg-white rounded-sm shadow-sm p-6">
            <div className="flex flex-col lg:flex-row gap-8">
              {/* Form Section */}
              <div className="flex-1 min-w-0">
                <ProfileForm />
              </div>

              {/* Profile Picture Section */}
              <div className="lg:w-[280px] flex-shrink-0">
                <div className="lg:sticky lg:top-[80px]">
                  <ProfilePicture userName="H" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* Help Button */}
      <HelpButton />
    </div>
  );
}

export default App;
