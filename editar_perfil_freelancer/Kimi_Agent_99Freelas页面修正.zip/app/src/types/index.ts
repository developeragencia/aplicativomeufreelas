export interface ProfileFormData {
  fullName: string;
  nickname: string;
  professionalTitle: string;
  aboutYou: string;
  experience: string;
  skills: string[];
  interests: string[];
}

export interface InterestItem {
  id: string;
  label: string;
  subItems?: string[];
}

export interface FormInputProps {
  label: string;
  name: string;
  type?: string;
  placeholder?: string;
  helperText?: string;
  value?: string;
  onChange?: (value: string) => void;
  error?: string;
}

export interface FormTextareaProps {
  label: string;
  name: string;
  placeholder?: string;
  helperText?: string;
  maxLength?: number;
  value?: string;
  onChange?: (value: string) => void;
  error?: string;
}
