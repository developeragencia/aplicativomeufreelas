import { useState } from 'react';
import { Header } from '@/components/Header';
import { Footer } from '@/components/Footer';
import { HelpButton } from '@/components/HelpButton';
import { ProjectCard } from '@/components/ProjectCard';
import { ChevronDown } from 'lucide-react';
import type { Project } from '@/types';

// Status options
const statusOptions = [
  { value: 'all', label: 'Todos os status' },
  { value: 'open', label: 'Aberto' },
  { value: 'in-progress', label: 'Em andamento' },
  { value: 'completed', label: 'Concluído' },
  { value: 'cancelled', label: 'Cancelado' },
];

// Limit options
const limitOptions = [
  { value: 10, label: '10 últimos' },
  { value: 20, label: '20 últimos' },
  { value: 50, label: '50 últimos' },
  { value: 100, label: '100 últimos' },
];

// Sample projects data (empty by default to match screenshot)
const sampleProjects: Project[] = [
  // Uncomment to test with data:
  /*
  {
    id: '1',
    title: 'Otimização e gestão do perfil no Google Meu Negócio',
    category: 'Marketing Digital',
    level: 'Intermediário',
    publishedAt: '1 dia atrás',
    timeRemaining: '28 dias e 13 horas',
    proposals: 40,
    interested: 43,
    description: 'Caros, gostaria de receber orçamentos de profissionais com experiência comprovada em otimização e gestão do perfil no Google Meu Negócio, de modo que minha página apareça entre as primeiras na pesquisa do Google.',
    client: {
      name: 'Victor S.',
      rating: 5,
      reviews: 3,
    },
    isFeatured: true,
  },
  {
    id: '2',
    title: 'Implantação Bitrix24 - Sum',
    category: 'Marketing Digital',
    level: 'Especialista',
    publishedAt: '1 dia atrás',
    timeRemaining: '5 dias e 10 horas',
    proposals: 7,
    interested: 11,
    description: 'Implantação do Bitrix24 para a Sum.',
    client: {
      name: 'Felipe M.',
      rating: 0,
      reviews: 0,
    },
    tags: ['CRM'],
    isFeatured: true,
  },
  */
];

export function MyProjects() {
  const [status, setStatus] = useState('all');
  const [limit, setLimit] = useState(20);
  const [projects] = useState<Project[]>(sampleProjects);

  return (
    <div className="min-h-screen flex flex-col bg-white">
      <Header userType="client" searchPlaceholder="Buscar freelancers" />
      
      <main className="flex-1 py-8 px-4">
        <div className="max-w-[1200px] mx-auto">
          <h1 className="text-[28px] font-normal text-freelas-text mb-6">
            Meus Projetos
          </h1>

          {/* Filters */}
          <div className="flex flex-wrap gap-4 mb-8">
            {/* Status Filter */}
            <div className="relative">
              <select
                value={status}
                onChange={(e) => setStatus(e.target.value)}
                className="w-[200px] h-[42px] px-3 pr-10 border border-freelas-border rounded text-sm text-freelas-text bg-white appearance-none focus:border-freelas-primary focus:outline-none transition-colors"
              >
                {statusOptions.map((option) => (
                  <option key={option.value} value={option.value}>
                    {option.label}
                  </option>
                ))}
              </select>
              <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 text-freelas-text-muted pointer-events-none" size={16} />
            </div>

            {/* Limit Filter */}
            <div className="relative">
              <select
                value={limit}
                onChange={(e) => setLimit(Number(e.target.value))}
                className="w-[200px] h-[42px] px-3 pr-10 border border-freelas-border rounded text-sm text-freelas-text bg-white appearance-none focus:border-freelas-primary focus:outline-none transition-colors"
              >
                {limitOptions.map((option) => (
                  <option key={option.value} value={option.value}>
                    {option.label}
                  </option>
                ))}
              </select>
              <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 text-freelas-text-muted pointer-events-none" size={16} />
            </div>
          </div>

          {/* Projects List */}
          {projects.length === 0 ? (
            <div className="py-12">
              <p className="text-freelas-text-secondary text-base">
                Nenhum projeto foi encontrado.
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              {projects.map((project) => (
                <ProjectCard key={project.id} project={project} />
              ))}
            </div>
          )}
        </div>
      </main>

      <Footer />
      <HelpButton />
    </div>
  );
}
