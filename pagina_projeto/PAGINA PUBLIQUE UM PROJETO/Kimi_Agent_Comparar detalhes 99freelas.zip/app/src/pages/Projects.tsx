import { useState } from 'react';
import { Header } from '@/components/Header';
import { Footer } from '@/components/Footer';
import { HelpButton } from '@/components/HelpButton';
import { ProjectCard } from '@/components/ProjectCard';
import { ChevronDown } from 'lucide-react';
import type { Project } from '@/types';

// Sort options
const sortOptions = [
  { value: 'relevance', label: 'Relevância' },
  { value: 'newest', label: 'Mais recentes' },
  { value: 'deadline', label: 'Prazo' },
  { value: 'proposals', label: 'Mais propostas' },
];

// Categories
const categories = [
  'Todas as categorias',
  'Administração & Contabilidade',
  'Advogados & Leis',
  'Atendimento ao Consumidor',
  'Design & Criação',
  'Educação & Consultoria',
  'Engenharia & Arquitetura',
  'Escrita',
  'Fotografia & AudioVisual',
  'Suporte Administrativo',
  'Tradução',
  'Vendas & Marketing',
  'Web, Mobile & Software',
];

// Sample projects data
const sampleProjects: Project[] = [
  {
    id: '1',
    title: 'Otimização e gestão do perfil no Google Meu Negócio',
    category: 'Marketing Digital',
    level: 'Intermediário',
    publishedAt: '1 dia atrás',
    timeRemaining: '28 dias e 13 horas',
    proposals: 40,
    interested: 43,
    description: 'Caros, gostaria de receber orçamentos de profissionais com experiência comprovada em otimização e gestão do perfil no Google Meu Negócio, de modo que minha página apareça entre as primeiras na pesquisa do Google.\n\nSegue link da minha página: https://share.google/...\n\nDesde já agradeço aos interessados.',
    client: {
      name: 'Victor S.',
      rating: 5,
      reviews: 3,
    },
    isFeatured: true,
  },
  {
    id: '2',
    title: 'Implantação Bitrix24 - Sum',
    category: 'Marketing Digital',
    level: 'Especialista',
    publishedAt: '1 dia atrás',
    timeRemaining: '5 dias e 10 horas',
    proposals: 7,
    interested: 11,
    description: 'Implantação do Bitrix24 para a Sum.\n\n• Configuração do CRM completo, incluindo funis de vendas e base de clientes.\n• Criação de base de preços e de produtos/serviços para geração automática de orçamentos.\n• Automação de processos, incluindo cálculos de impostos, descontos e fluxos de trabalho internos.',
    client: {
      name: 'Felipe M.',
      rating: 0,
      reviews: 0,
    },
    tags: ['CRM'],
    isFeatured: true,
  },
  {
    id: '3',
    title: 'Lançamento de SaaS Completo para Clínicas de estética com IA',
    category: 'Marketing Digital',
    level: 'Iniciante',
    publishedAt: '5 minutos atrás',
    timeRemaining: '29 dias e 23 horas',
    proposals: 0,
    interested: 0,
    description: 'Estou com um SaaS 100% funcional e já estruturado, voltado para clínicas, e preciso de um especialista para conduzir o lançamento estratégico e aquisição de clientes.\n\nO sistema já possui:\n\n? Gestão Completa da Clínica\n• Cadastro da clínica\n• Criação de recepcionistas\n• Criação de múltiplos...',
    client: {
      name: 'Anônimo',
      rating: 0,
      reviews: 0,
    },
    isFeatured: true,
  },
  {
    id: '4',
    title: 'SAC Especializado para em Marca de coisas para casa',
    category: 'Atendimento ao Consumidor',
    level: 'Iniciante',
    publishedAt: '7 minutos atrás',
    timeRemaining: '29 dias e 23 horas',
    proposals: 0,
    interested: 0,
    description: 'Nossa marca de casa busca um profissional que seja a voz da nossa empresa para acolher e auxiliar nossas clientes. No setor de beleza, o atendimento é o coração da marca; por isso, buscamos alguém que une conhecimento técnico a uma empatia excepcional.\n\nPrincipais Responsabilidades:\n• Prestar suporte...',
    client: {
      name: 'Matheus S.',
      rating: 0,
      reviews: 0,
    },
    isFeatured: true,
  },
  {
    id: '5',
    title: 'Artigo de saúde coletiva correção e adequação a modelo',
    category: 'Outra Categoria',
    level: 'Intermediário',
    publishedAt: '10 minutos atrás',
    timeRemaining: '2 dias e 23 horas',
    proposals: 0,
    interested: 0,
    description: 'Realizar a correção do texto de pesquisa (já feito uma prévia) e adequar ao modelo que será enviado.',
    client: {
      name: 'Anônimo',
      rating: 0,
      reviews: 0,
    },
    tags: ['Artigos Médicos', 'Escrita Médica', 'Escrita Técnica', 'Medicina Acadêmica', 'Saúde'],
    isFeatured: true,
  },
  {
    id: '6',
    title: 'Integração com ifood.....',
    category: 'Desenvolvimento Web',
    level: 'Intermediário',
    publishedAt: '13 minutos atrás',
    timeRemaining: '29 dias e 23 horas',
    proposals: 0,
    interested: 0,
    description: 'Tenho uma empresa de entregadores, tenho várias empresas como clientes. Meus clientes querem cadastrar a empresa no ifood e etc. Mas querem usar meu sistema e meus entregadores! Quero que ao receber o pedido do ifood tenha a integração para ir ao meu sistema sem precisar cadastrar tudo manualmente!',
    client: {
      name: 'Anônimo',
      rating: 5,
      reviews: 1,
    },
    isFeatured: true,
  },
];

export function Projects() {
  const [sortBy, setSortBy] = useState('relevance');
  const [currentPage, setCurrentPage] = useState(1);
  const [filterKeyword, setFilterKeyword] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('Todas as categorias');

  const totalProjects = 1694;

  return (
    <div className="min-h-screen flex flex-col bg-white">
      <Header userType="freelancer" searchPlaceholder="Buscar projetos" />
      
      <main className="flex-1 py-8 px-4">
        <div className="max-w-[1200px] mx-auto">
          {/* Header with results count and publish button */}
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-6">
            <div>
              <h1 className="text-[24px] font-normal text-freelas-text">
                Resultado da pesquisa
              </h1>
              <p className="text-sm text-freelas-text-secondary">
                {totalProjects} projetos foram encontrados
              </p>
            </div>
            <button className="bg-freelas-primary hover:bg-freelas-primary-dark text-white px-4 py-2 rounded text-sm font-medium transition-colors duration-200 whitespace-nowrap">
              Publique um projeto. É grátis.
            </button>
          </div>

          <div className="flex flex-col lg:flex-row gap-6">
            {/* Sidebar Filters */}
            <aside className="w-full lg:w-[280px] flex-shrink-0">
              {/* My Filters */}
              <div className="border border-freelas-border rounded p-4 mb-4">
                <h3 className="font-semibold text-freelas-text mb-3">Meus Filtros</h3>
                <p className="text-sm text-freelas-text-secondary mb-3">
                  Você não tem nenhum filtro cadastrado
                </p>
                <div className="flex gap-2">
                  <input
                    type="text"
                    placeholder="Ex. Projetos Web"
                    className="flex-1 h-[36px] px-3 border border-freelas-border rounded text-sm focus:border-freelas-primary focus:outline-none"
                  />
                  <button className="bg-freelas-primary hover:bg-freelas-primary-dark text-white px-3 py-1 rounded text-sm transition-colors">
                    Salvar
                  </button>
                </div>
              </div>

              {/* Keywords */}
              <div className="border border-freelas-border rounded p-4 mb-4">
                <h3 className="font-semibold text-freelas-text mb-3">Palavras-chaves</h3>
                <div className="flex gap-2">
                  <input
                    type="text"
                    placeholder="Ex. HTML, CSS, JavaScript"
                    value={filterKeyword}
                    onChange={(e) => setFilterKeyword(e.target.value)}
                    className="flex-1 h-[36px] px-3 border border-freelas-border rounded text-sm focus:border-freelas-primary focus:outline-none"
                  />
                  <button className="bg-freelas-primary hover:bg-freelas-primary-dark text-white px-3 py-1 rounded text-sm transition-colors">
                    Ok
                  </button>
                </div>
              </div>

              {/* Categories */}
              <div className="border border-freelas-border rounded p-4 mb-4">
                <h3 className="font-semibold text-freelas-text mb-3">Categorias</h3>
                <ul className="space-y-2">
                  {categories.map((cat) => (
                    <li key={cat}>
                      <button
                        onClick={() => setSelectedCategory(cat)}
                        className={`text-sm hover:text-freelas-primary transition-colors ${
                          selectedCategory === cat
                            ? 'text-freelas-primary font-medium'
                            : 'text-freelas-text-secondary'
                        }`}
                      >
                        {cat}
                      </button>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Project Type */}
              <div className="border border-freelas-border rounded p-4 mb-4">
                <h3 className="font-semibold text-freelas-text mb-3">Tipo de projeto</h3>
                <ul className="space-y-2">
                  <li>
                    <label className="flex items-center gap-2 text-sm text-freelas-text-secondary cursor-pointer">
                      <input type="checkbox" className="rounded border-freelas-border" />
                      Todos os projetos
                    </label>
                  </li>
                  <li>
                    <label className="flex items-center gap-2 text-sm text-freelas-text-secondary cursor-pointer">
                      <input type="checkbox" className="rounded border-freelas-border" />
                      Projetos em destaque
                    </label>
                  </li>
                  <li>
                    <label className="flex items-center gap-2 text-sm text-freelas-text-secondary cursor-pointer">
                      <input type="checkbox" className="rounded border-freelas-border" />
                      Projetos urgentes
                    </label>
                  </li>
                </ul>
              </div>

              {/* Publication Date */}
              <div className="border border-freelas-border rounded p-4 mb-4">
                <h3 className="font-semibold text-freelas-text mb-3">Data da publicação</h3>
                <ul className="space-y-2">
                  <li>
                    <button className="text-sm text-freelas-primary font-medium hover:underline">
                      Qualquer hora
                    </button>
                  </li>
                  <li>
                    <button className="text-sm text-freelas-text-secondary hover:text-freelas-primary transition-colors">
                      Menos de 24 horas atrás
                    </button>
                  </li>
                  <li>
                    <button className="text-sm text-freelas-text-secondary hover:text-freelas-primary transition-colors">
                      Menos de 3 dias atrás
                    </button>
                  </li>
                </ul>
              </div>

              {/* Client Ranking */}
              <div className="border border-freelas-border rounded p-4 mb-4">
                <h3 className="font-semibold text-freelas-text mb-3">Ranking do cliente</h3>
                <ul className="space-y-2">
                  <li>
                    <button className="text-sm text-freelas-primary font-medium hover:underline">
                      Qualquer ranking
                    </button>
                  </li>
                  <li>
                    <button className="text-sm text-freelas-text-secondary hover:text-freelas-primary transition-colors">
                      5 estrelas
                    </button>
                  </li>
                  <li>
                    <button className="text-sm text-freelas-text-secondary hover:text-freelas-primary transition-colors">
                      Pelo menos 4.5 estrelas
                    </button>
                  </li>
                  <li>
                    <button className="text-sm text-freelas-text-secondary hover:text-freelas-primary transition-colors">
                      Pelo menos 4 estrelas
                    </button>
                  </li>
                  <li>
                    <button className="text-sm text-freelas-text-secondary hover:text-freelas-primary transition-colors">
                      Sem feedback
                    </button>
                  </li>
                </ul>
              </div>

              {/* Experience Level */}
              <div className="border border-freelas-border rounded p-4 mb-4">
                <h3 className="font-semibold text-freelas-text mb-3">Nível de experiência</h3>
                <ul className="space-y-2">
                  <li>
                    <button className="text-sm text-freelas-primary font-medium hover:underline">
                      Todos os níveis de experiência
                    </button>
                  </li>
                  <li>
                    <label className="flex items-center gap-2 text-sm text-freelas-text-secondary cursor-pointer">
                      <input type="checkbox" className="rounded border-freelas-border" />
                      Iniciante
                    </label>
                  </li>
                  <li>
                    <label className="flex items-center gap-2 text-sm text-freelas-text-secondary cursor-pointer">
                      <input type="checkbox" className="rounded border-freelas-border" />
                      Intermediário
                    </label>
                  </li>
                  <li>
                    <label className="flex items-center gap-2 text-sm text-freelas-text-secondary cursor-pointer">
                      <input type="checkbox" className="rounded border-freelas-border" />
                      Especialista
                    </label>
                  </li>
                </ul>
              </div>

              {/* Other Filters */}
              <div className="border border-freelas-border rounded p-4 mb-4">
                <h3 className="font-semibold text-freelas-text mb-3">Outros filtros</h3>
                <ul className="space-y-2">
                  <li>
                    <button className="text-sm text-freelas-primary font-medium hover:underline">
                      Todos os projetos
                    </button>
                  </li>
                  <li>
                    <label className="flex items-center gap-2 text-sm text-freelas-text-secondary cursor-pointer">
                      <input type="checkbox" className="rounded border-freelas-border" />
                      Projetos visualizados
                    </label>
                  </li>
                  <li>
                    <label className="flex items-center gap-2 text-sm text-freelas-text-secondary cursor-pointer">
                      <input type="checkbox" className="rounded border-freelas-border" />
                      Projetos que já enviei proposta
                    </label>
                  </li>
                </ul>
              </div>

              {/* Reset Filters */}
              <button className="w-full bg-freelas-primary hover:bg-freelas-primary-dark text-white py-2 rounded text-sm font-medium transition-colors">
                Resetar Filtros
              </button>
            </aside>

            {/* Projects List */}
            <div className="flex-1">
              {/* Sort and Pagination */}
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-6">
                <div className="relative">
                  <select
                    value={sortBy}
                    onChange={(e) => setSortBy(e.target.value)}
                    className="w-[180px] h-[40px] px-3 pr-10 border border-freelas-border rounded text-sm text-freelas-text bg-white appearance-none focus:border-freelas-primary focus:outline-none transition-colors"
                  >
                    {sortOptions.map((option) => (
                      <option key={option.value} value={option.value}>
                        {option.label}
                      </option>
                    ))}
                  </select>
                  <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 text-freelas-text-muted pointer-events-none" size={16} />
                </div>

                {/* Pagination */}
                <div className="flex items-center gap-1">
                  {[1, 2, 3].map((page) => (
                    <button
                      key={page}
                      onClick={() => setCurrentPage(page)}
                      className={`w-8 h-8 flex items-center justify-center rounded text-sm font-medium transition-colors ${
                        currentPage === page
                          ? 'bg-freelas-primary text-white'
                          : 'bg-white border border-freelas-border text-freelas-text hover:bg-gray-50'
                      }`}
                    >
                      {page}
                    </button>
                  ))}
                  <span className="px-2 text-freelas-text-muted">...</span>
                  <button className="px-3 h-8 flex items-center justify-center rounded text-sm text-freelas-text bg-white border border-freelas-border hover:bg-gray-50 transition-colors">
                    Última
                  </button>
                </div>
              </div>

              {/* Projects */}
              <div className="space-y-4">
                {sampleProjects.map((project) => (
                  <ProjectCard key={project.id} project={project} />
                ))}
              </div>

              {/* Bottom Pagination */}
              <div className="flex justify-end mt-6">
                <div className="flex items-center gap-1">
                  {[1, 2, 3].map((page) => (
                    <button
                      key={page}
                      onClick={() => setCurrentPage(page)}
                      className={`w-8 h-8 flex items-center justify-center rounded text-sm font-medium transition-colors ${
                        currentPage === page
                          ? 'bg-freelas-primary text-white'
                          : 'bg-white border border-freelas-border text-freelas-text hover:bg-gray-50'
                      }`}
                    >
                      {page}
                    </button>
                  ))}
                  <span className="px-2 text-freelas-text-muted">...</span>
                  <button className="px-3 h-8 flex items-center justify-center rounded text-sm text-freelas-text bg-white border border-freelas-border hover:bg-gray-50 transition-colors">
                    Última
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>

      <Footer />
      <HelpButton />
    </div>
  );
}
