import { useState } from 'react';
import { Header } from '@/components/Header';
import { Footer } from '@/components/Footer';
import { HelpButton } from '@/components/HelpButton';
import { ExperienceCard } from '@/components/ExperienceCard';
import { SkillSelector } from '@/components/SkillSelector';
import { FileUpload } from '@/components/FileUpload';
import { ChevronDown } from 'lucide-react';

// Sample skills data
const availableSkills = [
  { id: '1', name: '.NET Compact Framework' },
  { id: '2', name: '.NET Framework' },
  { id: '3', name: '.NET para Web' },
  { id: '4', name: '.NET Remoting' },
  { id: '5', name: '1ShoppingCart' },
  { id: '6', name: '3DS Max' },
  { id: '7', name: 'ABAP' },
  { id: '8', name: 'Adobe Illustrator' },
  { id: '9', name: 'Adobe Photoshop' },
  { id: '10', name: 'Angular' },
  { id: '11', name: 'AWS' },
  { id: '12', name: 'Azure' },
  { id: '13', name: 'Bootstrap' },
  { id: '14', name: 'C#' },
  { id: '15', name: 'C++' },
  { id: '16', name: 'CSS' },
  { id: '17', name: 'Django' },
  { id: '18', name: 'Docker' },
  { id: '19', name: 'Figma' },
  { id: '20', name: 'Flutter' },
  { id: '21', name: 'Git' },
  { id: '22', name: 'HTML' },
  { id: '23', name: 'Java' },
  { id: '24', name: 'JavaScript' },
  { id: '25', name: 'jQuery' },
  { id: '26', name: 'Kotlin' },
  { id: '27', name: 'Laravel' },
  { id: '28', name: 'MongoDB' },
  { id: '29', name: 'MySQL' },
  { id: '30', name: 'Node.js' },
  { id: '31', name: 'PHP' },
  { id: '32', name: 'Python' },
  { id: '33', name: 'React' },
  { id: '34', name: 'Ruby' },
  { id: '35', name: 'Rust' },
  { id: '36', name: 'Sass' },
  { id: '37', name: 'SQL' },
  { id: '38', name: 'Swift' },
  { id: '39', name: 'TypeScript' },
  { id: '40', name: 'Vue.js' },
  { id: '41', name: 'WordPress' },
];

// Categories
const categories = [
  'Administração & Contabilidade',
  'Advogados & Leis',
  'Atendimento ao Consumidor',
  'Design & Criação',
  'Educação & Consultoria',
  'Engenharia & Arquitetura',
  'Escrita',
  'Fotografia & AudioVisual',
  'Marketing Digital',
  'Suporte Administrativo',
  'Tradução',
  'Vendas & Marketing',
  'Web, Mobile & Software',
];

// Proposal days options
const proposalDaysOptions = [
  { value: 7, label: '7 dias' },
  { value: 14, label: '14 dias' },
  { value: 30, label: '30 dias' },
  { value: 60, label: '60 dias' },
];

const experienceLevels = [
  {
    level: 'Iniciante' as const,
    description: 'Estou a procura de freelancers com os menores valores.',
  },
  {
    level: 'Intermediário' as const,
    description: 'Estou a procura de uma combinação de experiência e valor.',
  },
  {
    level: 'Especialista' as const,
    description: 'Estou disposto a pagar valores mais elevados para freelancers experientes.',
  },
];

export function ProjectNew() {
  const [formData, setFormData] = useState({
    category: '',
    name: '',
    description: '',
    files: [] as File[],
    skills: [] as string[],
    experienceLevel: 'Iniciante' as 'Iniciante' | 'Intermediário' | 'Especialista',
    proposalDays: 30,
    visibility: 'public' as 'public' | 'private',
  });

  const [nameCount, setNameCount] = useState(0);
  const [descCount, setDescCount] = useState(0);
  const [faqOpen, setFaqOpen] = useState(false);

  const handleNameChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    if (value.length <= 75) {
      setFormData({ ...formData, name: value });
      setNameCount(value.length);
    }
  };

  const handleDescChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const value = e.target.value;
    if (value.length <= 5000) {
      setFormData({ ...formData, description: value });
      setDescCount(value.length);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Form submitted:', formData);
    alert('Projeto publicado com sucesso!');
  };

  return (
    <div className="min-h-screen flex flex-col bg-white">
      <Header userType="client" searchPlaceholder="Buscar freelancers" />
      
      <main className="flex-1 py-8 px-4">
        <div className="max-w-[800px] mx-auto">
          <h1 className="text-[28px] font-normal text-freelas-text mb-8">
            Publique um projeto
          </h1>

          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Category */}
            <div>
              <label className="block text-sm font-semibold text-freelas-text mb-2">
                Escolha uma categoria
              </label>
              <div className="relative">
                <select
                  value={formData.category}
                  onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                  className="w-full h-[42px] px-3 pr-10 border border-freelas-border rounded text-sm text-freelas-text bg-white appearance-none focus:border-freelas-primary focus:outline-none transition-colors"
                >
                  <option value="">Selecione uma categoria</option>
                  {categories.map((cat) => (
                    <option key={cat} value={cat}>
                      {cat}
                    </option>
                  ))}
                </select>
                <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 text-freelas-text-muted pointer-events-none" size={16} />
              </div>
            </div>

            {/* Project Name */}
            <div>
              <label className="block text-sm font-semibold text-freelas-text mb-2">
                Dê um nome para o trabalho
              </label>
              <input
                type="text"
                value={formData.name}
                onChange={handleNameChange}
                placeholder="Ex. Redator para blog de tecnologia"
                className="w-full h-[42px] px-3 border border-freelas-border rounded text-sm text-freelas-text placeholder:text-freelas-text-muted focus:border-freelas-primary focus:outline-none transition-colors"
              />
              <div className="text-right text-xs text-freelas-text-muted mt-1">
                {nameCount}/75
              </div>
            </div>

            {/* Description */}
            <div>
              <label className="block text-sm font-semibold text-freelas-text mb-2">
                Descreva o trabalho a ser feito
              </label>
              <textarea
                value={formData.description}
                onChange={handleDescChange}
                rows={5}
                className="w-full px-3 py-2 border border-freelas-border rounded text-sm text-freelas-text placeholder:text-freelas-text-muted focus:border-freelas-primary focus:outline-none transition-colors resize-none"
              />
              <div className="text-right text-xs text-freelas-text-muted mt-1">
                {descCount}/5000
              </div>
            </div>

            {/* File Upload */}
            <div>
              <label className="block text-sm font-semibold text-freelas-text mb-2">
                Anexe um arquivo <span className="font-normal text-freelas-text-secondary">(Opcional)</span>
              </label>
              <FileUpload
                onUpload={(files) => setFormData({ ...formData, files })}
              />
            </div>

            {/* Skills */}
            <div>
              <label className="block text-sm font-semibold text-freelas-text mb-2">
                Quais habilidades são desejadas? <span className="font-normal text-freelas-text-secondary">(Opcional)</span>
              </label>
              <SkillSelector
                skills={availableSkills}
                selected={formData.skills}
                onChange={(skills) => setFormData({ ...formData, skills })}
                maxSelection={5}
              />
            </div>

            {/* Experience Level */}
            <div>
              <label className="block text-sm font-semibold text-freelas-text mb-3">
                Nível de experiência desejado
              </label>
              <div className="flex flex-col sm:flex-row gap-3">
                {experienceLevels.map((exp) => (
                  <ExperienceCard
                    key={exp.level}
                    level={exp.level}
                    description={exp.description}
                    selected={formData.experienceLevel === exp.level}
                    onSelect={() => setFormData({ ...formData, experienceLevel: exp.level })}
                  />
                ))}
              </div>
            </div>

            {/* Proposal Days */}
            <div>
              <label className="block text-sm font-semibold text-freelas-text mb-2">
                Durante quantos dias você quer receber propostas?
              </label>
              <div className="relative max-w-[200px]">
                <select
                  value={formData.proposalDays}
                  onChange={(e) => setFormData({ ...formData, proposalDays: Number(e.target.value) })}
                  className="w-full h-[42px] px-3 pr-10 border border-freelas-border rounded text-sm text-freelas-text bg-white appearance-none focus:border-freelas-primary focus:outline-none transition-colors"
                >
                  {proposalDaysOptions.map((option) => (
                    <option key={option.value} value={option.value}>
                      {option.label}
                    </option>
                  ))}
                </select>
                <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 text-freelas-text-muted pointer-events-none" size={16} />
              </div>
            </div>

            {/* Visibility */}
            <div>
              <label className="block text-sm font-semibold text-freelas-text mb-3">
                Visibilidade do projeto
              </label>
              <div className="space-y-3">
                <label className="flex items-start gap-3 cursor-pointer">
                  <input
                    type="radio"
                    name="visibility"
                    value="public"
                    checked={formData.visibility === 'public'}
                    onChange={(e) => setFormData({ ...formData, visibility: e.target.value as 'public' | 'private' })}
                    className="mt-1 w-4 h-4 text-freelas-primary border-freelas-border focus:ring-freelas-primary"
                  />
                  <div>
                    <span className="block text-sm font-medium text-freelas-text">Público</span>
                    <span className="block text-sm text-freelas-text-secondary">
                      Visível para todos os profissionais.
                    </span>
                  </div>
                </label>
                <label className="flex items-start gap-3 cursor-pointer">
                  <input
                    type="radio"
                    name="visibility"
                    value="private"
                    checked={formData.visibility === 'private'}
                    onChange={(e) => setFormData({ ...formData, visibility: e.target.value as 'public' | 'private' })}
                    className="mt-1 w-4 h-4 text-freelas-primary border-freelas-border focus:ring-freelas-primary"
                  />
                  <div>
                    <span className="block text-sm font-medium text-freelas-text">Privado</span>
                    <span className="block text-sm text-freelas-text-secondary">
                      Apenas os freelancers que forem convidados poderão se candidatar.
                    </span>
                  </div>
                </label>
              </div>
            </div>

            {/* Submit Button */}
            <div className="pt-4">
              <button
                type="submit"
                className="bg-freelas-secondary hover:bg-freelas-secondary-dark text-white px-6 py-3 rounded text-sm font-semibold transition-colors duration-200"
              >
                Publicar projeto
              </button>
            </div>
          </form>

          {/* FAQ Section */}
          <div className="mt-10 pt-6 border-t border-freelas-border">
            <button
              onClick={() => setFaqOpen(!faqOpen)}
              className="flex items-center gap-2 text-freelas-text-secondary hover:text-freelas-text transition-colors"
            >
              <span className="text-lg">Perguntas Frequentes</span>
              <span className="text-sm">({faqOpen ? 'Ocultar' : 'Exibir'})</span>
            </button>
            
            {faqOpen && (
              <div className="mt-4 space-y-4 text-sm text-freelas-text-secondary">
                <div>
                  <h4 className="font-semibold text-freelas-text mb-1">Quanto custa publicar um projeto?</h4>
                  <p>É gratuito publicar projetos na 99Freelas. Você só paga quando contratar um freelancer.</p>
                </div>
                <div>
                  <h4 className="font-semibold text-freelas-text mb-1">Como recebo propostas?</h4>
                  <p>Os freelancers interessados enviarão propostas diretamente pelo site, com valores e prazos.</p>
                </div>
                <div>
                  <h4 className="font-semibold text-freelas-text mb-1">Posso editar meu projeto depois?</h4>
                  <p>Sim, você pode editar as informações do projeto a qualquer momento antes de contratar.</p>
                </div>
              </div>
            )}
          </div>
        </div>
      </main>

      <Footer />
      <HelpButton />
    </div>
  );
}
