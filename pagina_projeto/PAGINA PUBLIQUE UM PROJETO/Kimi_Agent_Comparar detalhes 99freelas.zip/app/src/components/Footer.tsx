export function Footer() {
  return (
    <footer className="bg-freelas-footer py-4 px-4 mt-auto">
      <div className="max-w-[1200px] mx-auto text-center">
        <p className="text-freelas-text-secondary text-xs">
          ©2014-2026 99Freelas. Todos os direitos reservados.
        </p>
        <p className="text-freelas-text-secondary text-xs mt-1">
          <a href="#" className="text-freelas-primary hover:underline">Termos de uso</a>
          {' | '}
          <a href="#" className="text-freelas-primary hover:underline">Política de privacidade</a>
        </p>
      </div>
    </footer>
  );
}
