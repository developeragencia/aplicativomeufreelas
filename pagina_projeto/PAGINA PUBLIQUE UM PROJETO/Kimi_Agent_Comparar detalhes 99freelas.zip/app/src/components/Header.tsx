import { useState } from 'react';
import { Search, MessageSquare, Bell, ChevronDown, Menu, X } from 'lucide-react';

interface HeaderProps {
  userType?: 'client' | 'freelancer';
  userName?: string;
  searchPlaceholder?: string;
}

export function Header({ 
  userType = 'client', 
  userName = 'Hugo Carvana',
  searchPlaceholder = 'Buscar freelancers'
}: HeaderProps) {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isUserMenuOpen, setIsUserMenuOpen] = useState(false);

  const navItems = [
    { label: 'Página inicial', href: '#' },
    { label: 'Projetos', href: '#', active: true },
    { label: 'Freelancers', href: '#' },
    { label: 'Perfil', href: '#' },
    { label: 'Conta', href: '#' },
    { label: 'Ferramentas', href: '#' },
    { label: 'Ajuda', href: '#' },
  ];

  return (
    <header className="w-full">
      {/* Top Header */}
      <div className="bg-freelas-header h-[60px] flex items-center px-4">
        <div className="max-w-[1200px] mx-auto w-full flex items-center justify-between">
          {/* Logo */}
          <a href="/" className="flex items-center gap-1">
            <span className="text-white text-2xl font-bold tracking-tight">
              99<span className="font-normal">freelas</span>
            </span>
            <span className="text-white text-xs">👑</span>
          </a>

          {/* Search Bar - Desktop */}
          <div className="hidden md:flex items-center flex-1 max-w-md mx-8">
            <div className="relative w-full">
              <select className="absolute left-0 top-0 h-[38px] bg-freelas-primary text-white text-sm px-3 pr-8 rounded-l border-none outline-none cursor-pointer appearance-none">
                <option>Freelancers</option>
                <option>Projetos</option>
              </select>
              <input
                type="text"
                placeholder={searchPlaceholder}
                className="w-full h-[38px] pl-[110px] pr-10 rounded text-sm border-none outline-none"
              />
              <button className="absolute right-0 top-0 h-[38px] w-[38px] bg-white rounded-r flex items-center justify-center text-freelas-text-muted hover:text-freelas-primary transition-colors">
                <Search size={18} />
              </button>
            </div>
          </div>

          {/* User Menu - Desktop */}
          <div className="hidden md:flex items-center gap-4">
            {/* Messages */}
            <button className="text-white hover:text-freelas-primary transition-colors">
              <MessageSquare size={22} />
            </button>
            
            {/* Notifications */}
            <button className="text-white hover:text-freelas-primary transition-colors">
              <Bell size={22} />
            </button>

            {/* User Dropdown */}
            <div className="relative">
              <button
                onClick={() => setIsUserMenuOpen(!isUserMenuOpen)}
                className="flex items-center gap-2 text-white hover:opacity-80 transition-opacity"
              >
                <div className="w-8 h-8 bg-freelas-secondary rounded flex items-center justify-center text-white font-semibold text-sm">
                  H
                </div>
                <span className="text-sm">{userName} ({userType === 'client' ? 'Cliente' : 'Freelancer'})</span>
                <ChevronDown size={16} />
              </button>
              
              {isUserMenuOpen && (
                <div className="absolute right-0 top-full mt-2 w-48 bg-white rounded shadow-lg border border-freelas-border z-50">
                  <a href="#" className="block px-4 py-2 text-sm text-freelas-text hover:bg-gray-100">Meu perfil</a>
                  <a href="#" className="block px-4 py-2 text-sm text-freelas-text hover:bg-gray-100">Configurações</a>
                  <a href="#" className="block px-4 py-2 text-sm text-freelas-text hover:bg-gray-100">Sair</a>
                </div>
              )}
            </div>
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="md:hidden text-white"
          >
            {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>

      {/* Navigation Bar */}
      <nav className="bg-freelas-nav h-[45px] hidden md:flex items-center px-4">
        <div className="max-w-[1200px] mx-auto w-full">
          <ul className="flex items-center gap-6">
            {navItems.map((item) => (
              <li key={item.label}>
                <a
                  href={item.href}
                  className={`text-white text-sm hover:bg-white/10 px-3 py-2 rounded transition-colors ${
                    item.active ? 'bg-white/10' : ''
                  }`}
                >
                  {item.label}
                </a>
              </li>
            ))}
          </ul>
        </div>
      </nav>

      {/* Mobile Menu */}
      {isMenuOpen && (
        <div className="md:hidden bg-freelas-header border-t border-white/10">
          <div className="p-4">
            {/* Mobile Search */}
            <div className="flex items-center mb-4">
              <div className="relative w-full">
                <select className="absolute left-0 top-0 h-[38px] bg-freelas-primary text-white text-sm px-3 pr-8 rounded-l border-none outline-none appearance-none">
                  <option>Freelancers</option>
                  <option>Projetos</option>
                </select>
                <input
                  type="text"
                  placeholder={searchPlaceholder}
                  className="w-full h-[38px] pl-[110px] pr-10 rounded text-sm border-none outline-none"
                />
                <button className="absolute right-0 top-0 h-[38px] w-[38px] bg-white rounded-r flex items-center justify-center text-freelas-text-muted">
                  <Search size={18} />
                </button>
              </div>
            </div>

            {/* Mobile Nav */}
            <ul className="space-y-2">
              {navItems.map((item) => (
                <li key={item.label}>
                  <a
                    href={item.href}
                    className="block text-white text-sm py-2 hover:bg-white/10 px-3 rounded transition-colors"
                  >
                    {item.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>
      )}
    </header>
  );
}
