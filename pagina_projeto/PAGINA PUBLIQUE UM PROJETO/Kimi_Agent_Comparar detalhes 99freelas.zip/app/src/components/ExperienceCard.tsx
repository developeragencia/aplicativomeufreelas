interface ExperienceCardProps {
  level: 'Iniciante' | 'Intermediário' | 'Especialista';
  description: string;
  selected: boolean;
  onSelect: () => void;
}

export function ExperienceCard({ level, description, selected, onSelect }: ExperienceCardProps) {
  return (
    <button
      type="button"
      onClick={onSelect}
      className={`flex-1 text-left p-4 rounded border-2 transition-all duration-200 hover:shadow-md ${
        selected
          ? 'border-freelas-primary bg-white'
          : 'border-freelas-border bg-white hover:border-freelas-primary/50'
      }`}
    >
      <h4 className={`font-semibold text-sm mb-2 ${
        selected ? 'text-freelas-primary' : 'text-freelas-text'
      }`}>
        {level}
      </h4>
      <p className="text-xs text-freelas-text-secondary leading-relaxed">
        {description}
      </p>
    </button>
  );
}
