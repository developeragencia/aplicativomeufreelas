import { useState, useRef, useEffect } from 'react';
import { X, ChevronDown } from 'lucide-react';

interface Skill {
  id: string;
  name: string;
}

interface SkillSelectorProps {
  skills: Skill[];
  selected: string[];
  onChange: (selected: string[]) => void;
  maxSelection?: number;
}

export function SkillSelector({ skills, selected, onChange, maxSelection = 5 }: SkillSelectorProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (containerRef.current && !containerRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const filteredSkills = skills.filter(skill =>
    skill.name.toLowerCase().includes(searchTerm.toLowerCase()) &&
    !selected.includes(skill.id)
  );

  const handleSelect = (skillId: string) => {
    if (selected.length < maxSelection) {
      onChange([...selected, skillId]);
      setSearchTerm('');
    }
  };

  const handleRemove = (skillId: string) => {
    onChange(selected.filter(id => id !== skillId));
  };

  const selectedSkills = skills.filter(skill => selected.includes(skill.id));

  return (
    <div ref={containerRef} className="relative">
      <div className="flex gap-4">
        {/* Skills Dropdown */}
        <div className="flex-1 relative">
          <div
            onClick={() => setIsOpen(!isOpen)}
            className="w-full h-[200px] border border-freelas-border rounded bg-white overflow-hidden cursor-pointer"
          >
            {isOpen && (
              <div className="p-2 border-b border-freelas-border">
                <input
                  type="text"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  placeholder="Buscar habilidade..."
                  className="w-full px-3 py-2 text-sm border border-freelas-border rounded focus:border-freelas-primary focus:outline-none"
                  onClick={(e) => e.stopPropagation()}
                />
              </div>
            )}
            <div className="overflow-y-auto h-[calc(100%-44px)]">
              {filteredSkills.map((skill) => (
                <div
                  key={skill.id}
                  onClick={(e) => {
                    e.stopPropagation();
                    handleSelect(skill.id);
                  }}
                  className="px-3 py-2 text-sm text-freelas-text hover:bg-gray-100 cursor-pointer"
                >
                  {skill.name}
                </div>
              ))}
              {filteredSkills.length === 0 && (
                <div className="px-3 py-4 text-sm text-freelas-text-muted text-center">
                  Nenhuma habilidade encontrada
                </div>
              )}
            </div>
          </div>
          <div className="absolute right-2 top-2 pointer-events-none">
            <ChevronDown size={16} className="text-freelas-text-muted" />
          </div>
        </div>

        {/* Selected Skills */}
        <div className="flex-1">
          <p className="text-sm text-freelas-text-secondary mb-2">
            Selecionadas (max {maxSelection})
          </p>
          <div className="border border-freelas-border rounded min-h-[200px] p-2 bg-white">
            {selectedSkills.length === 0 ? (
              <p className="text-sm text-freelas-text-muted text-center py-8">
                Nenhuma habilidade selecionada
              </p>
            ) : (
              <div className="flex flex-wrap gap-2">
                {selectedSkills.map((skill) => (
                  <span
                    key={skill.id}
                    className="inline-flex items-center gap-1 px-2 py-1 bg-freelas-primary/10 text-freelas-primary text-sm rounded"
                  >
                    {skill.name}
                    <button
                      type="button"
                      onClick={() => handleRemove(skill.id)}
                      className="hover:text-freelas-primary-dark"
                    >
                      <X size={14} />
                    </button>
                  </span>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
