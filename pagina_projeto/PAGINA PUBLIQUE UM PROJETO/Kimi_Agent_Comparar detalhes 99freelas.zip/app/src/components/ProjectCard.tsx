import { Star, Bookmark } from 'lucide-react';
import type { Project } from '@/types';

interface ProjectCardProps {
  project: Project;
}

export function ProjectCard({ project }: ProjectCardProps) {
  const renderStars = (rating: number) => {
    return Array.from({ length: 5 }, (_, i) => (
      <Star
        key={i}
        size={14}
        className={i < rating ? 'fill-freelas-star text-freelas-star' : 'text-gray-300'}
      />
    ));
  };

  return (
    <div className={`relative p-4 rounded border ${
      project.isFeatured 
        ? 'bg-freelas-card-featured border-yellow-200' 
        : 'bg-white border-freelas-border'
    }`}>
      {/* Bookmark */}
      <div className="absolute top-4 right-4">
        <Bookmark 
          size={24} 
          className={project.isFeatured ? 'fill-yellow-500 text-yellow-500' : 'text-gray-400'} 
        />
      </div>

      {/* Title */}
      <h3 className="text-lg font-medium text-freelas-primary hover:underline cursor-pointer mb-2 pr-8">
        {project.title}
      </h3>

      {/* Meta Info */}
      <div className="text-sm text-freelas-text-secondary mb-3">
        {project.category} | {project.level} | Publicado: {project.publishedAt} | 
        Tempo restante: {project.timeRemaining} | Propostas: {project.proposals} | 
        Interessados: {project.interested}
      </div>

      {/* Description */}
      <p className="text-sm text-freelas-text mb-3 line-clamp-3">
        {project.description}
      </p>

      {/* Tags */}
      {project.tags && project.tags.length > 0 && (
        <div className="flex flex-wrap gap-2 mb-3">
          {project.tags.map((tag, index) => (
            <span
              key={index}
              className="px-2 py-1 bg-gray-200 text-freelas-text-secondary text-xs rounded"
            >
              {tag}
            </span>
          ))}
        </div>
      )}

      {/* Client Info */}
      <div className="flex items-center gap-2 text-sm">
        <span className="text-freelas-text-secondary">Cliente:</span>
        <span className="text-freelas-text">{project.client.name}</span>
        <div className="flex items-center gap-0.5">
          {renderStars(project.client.rating)}
        </div>
        <span className="text-freelas-text-secondary">
          ({project.client.reviews} avaliações)
        </span>
      </div>
    </div>
  );
}
