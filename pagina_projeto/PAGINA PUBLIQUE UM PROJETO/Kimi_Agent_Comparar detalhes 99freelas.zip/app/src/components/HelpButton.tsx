import { HelpCircle } from 'lucide-react';

export function HelpButton() {
  return (
    <button
      className="fixed bottom-5 right-5 z-50 bg-freelas-primary hover:bg-freelas-primary-dark text-white px-4 py-3 rounded-full flex items-center gap-2 shadow-lg transition-colors duration-200"
      onClick={() => alert('Ajuda - Em breve!')}
    >
      <HelpCircle size={20} />
      <span className="font-medium">Ajuda</span>
    </button>
  );
}
