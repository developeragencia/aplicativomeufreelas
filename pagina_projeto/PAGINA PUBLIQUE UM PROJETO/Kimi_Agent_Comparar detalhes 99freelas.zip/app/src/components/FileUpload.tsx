import { useState, useRef } from 'react';
import { X, Upload } from 'lucide-react';

interface FileUploadProps {
  onUpload?: (files: File[]) => void;
}

export function FileUpload({ onUpload }: FileUploadProps) {
  const [files, setFiles] = useState<File[]>([]);
  const [isDragging, setIsDragging] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const droppedFiles = Array.from(e.dataTransfer.files);
    const newFiles = [...files, ...droppedFiles];
    setFiles(newFiles);
    onUpload?.(newFiles);
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const selectedFiles = Array.from(e.target.files);
      const newFiles = [...files, ...selectedFiles];
      setFiles(newFiles);
      onUpload?.(newFiles);
    }
  };

  const handleRemove = (index: number) => {
    const newFiles = files.filter((_, i) => i !== index);
    setFiles(newFiles);
    onUpload?.(newFiles);
  };

  return (
    <div>
      <div
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        className={`border-2 border-dashed rounded p-6 text-center transition-colors ${
          isDragging
            ? 'border-freelas-primary bg-freelas-primary/5'
            : 'border-freelas-border bg-white'
        }`}
      >
        <input
          ref={inputRef}
          type="file"
          multiple
          onChange={handleFileSelect}
          className="hidden"
        />
        
        <button
          type="button"
          onClick={() => inputRef.current?.click()}
          className="bg-freelas-secondary hover:bg-freelas-secondary-dark text-white px-4 py-2 rounded text-sm font-medium transition-colors duration-200"
        >
          Adicionar arquivos
        </button>
        
        <span className="ml-3 text-sm text-freelas-text-secondary">
          Ou se preferir arraste seus arquivos aqui.
        </span>
      </div>

      {files.length > 0 && (
        <div className="mt-4 space-y-2">
          {files.map((file, index) => (
            <div
              key={index}
              className="flex items-center justify-between px-3 py-2 bg-gray-50 rounded border border-freelas-border"
            >
              <div className="flex items-center gap-2">
                <Upload size={16} className="text-freelas-text-muted" />
                <span className="text-sm text-freelas-text">{file.name}</span>
                <span className="text-xs text-freelas-text-muted">
                  ({(file.size / 1024).toFixed(1)} KB)
                </span>
              </div>
              <button
                type="button"
                onClick={() => handleRemove(index)}
                className="text-freelas-text-muted hover:text-red-500 transition-colors"
              >
                <X size={16} />
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
