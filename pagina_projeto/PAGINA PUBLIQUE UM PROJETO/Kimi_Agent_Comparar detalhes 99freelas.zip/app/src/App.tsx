import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { ProjectNew } from '@/pages/ProjectNew';
import { MyProjects } from '@/pages/MyProjects';
import { Projects } from '@/pages/Projects';

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Navigate to="/project/new" replace />} />
        <Route path="/project/new" element={<ProjectNew />} />
        <Route path="/my-projects" element={<MyProjects />} />
        <Route path="/projects" element={<Projects />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
