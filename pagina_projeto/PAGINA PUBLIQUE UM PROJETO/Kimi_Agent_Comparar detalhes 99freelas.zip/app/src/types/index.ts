export interface Project {
  id: string;
  title: string;
  category: string;
  level: 'Iniciante' | 'Intermediário' | 'Especialista';
  publishedAt: string;
  timeRemaining: string;
  proposals: number;
  interested: number;
  description: string;
  client: {
    name: string;
    rating: number;
    reviews: number;
  };
  tags?: string[];
  isFeatured?: boolean;
}

export interface ProjectFormData {
  category: string;
  name: string;
  description: string;
  files: File[];
  skills: string[];
  experienceLevel: 'Iniciante' | 'Intermediário' | 'Especialista';
  proposalDays: number;
  visibility: 'public' | 'private';
}

export interface Skill {
  id: string;
  name: string;
}

export interface Category {
  id: string;
  name: string;
}
