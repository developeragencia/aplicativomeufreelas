# 99Freelas - Technical Specification

## 1. Tech Stack Overview

| Category | Technology |
|----------|------------|
| Framework | React 18 + TypeScript |
| Build Tool | Vite |
| Styling | Tailwind CSS |
| UI Components | shadcn/ui |
| Routing | React Router DOM |
| Icons | Lucide React |
| State | React useState/useContext |

## 2. Tailwind Configuration

```javascript
// tailwind.config.js extensions
{
  theme: {
    extend: {
      colors: {
        primary: {
          DEFAULT: '#00A8C6',
          dark: '#008BA8',
        },
        secondary: {
          DEFAULT: '#4CAF50',
          dark: '#3D8B40',
        },
        header: '#2C3E50',
        'nav-bg': '#00A8C6',
        'footer-bg': '#F5F5F5',
        star: '#FFC107',
        'card-featured': '#FFF8E1',
      },
      fontFamily: {
        sans: ['Arial', 'sans-serif'],
      },
    },
  },
}
```

## 3. Component Inventory

### Shadcn/UI Components (Pre-installed)

| Component | Usage | Style Overrides |
|-----------|-------|-----------------|
| Button | All buttons | Custom colors for primary/secondary |
| Input | Form fields | Border color override |
| Select | Dropdowns | Match design colors |
| Textarea | Description field | Character counter |
| RadioGroup | Visibility options | Custom styling |
| Label | Form labels | Font weight 600 |

### Custom Components

| Component | Props | Description |
|-----------|-------|-------------|
| Header | userType: 'client' \| 'freelancer' | Top navigation with search |
| Navigation | activeItem: string | Cyan nav bar |
| Footer | - | Copyright footer |
| HelpButton | - | Floating help button |
| ExperienceCard | level, description, selected, onSelect | Selectable experience level |
| SkillSelector | skills, selected, onChange | Multi-select with search |
| FileUpload | onUpload | Drag & drop file upload |
| ProjectCard | project: Project | Project listing card |

## 4. Animation Implementation Plan

| Interaction | Tech | Implementation |
|-------------|------|----------------|
| Button hover | Tailwind | `hover:bg-primary-dark transition-colors duration-200` |
| Input focus | Tailwind | `focus:border-primary focus:ring-1 focus:ring-primary transition-colors` |
| Card hover | Tailwind | `hover:shadow-md hover:-translate-y-0.5 transition-all duration-200` |
| Experience card select | React state | Conditional border class `border-3 border-primary` |
| Page transitions | CSS | Fade in with opacity animation |
| Dropdown open | Tailwind | `transition-all duration-150` |

## 5. Project File Structure

```
src/
├── components/
│   ├── ui/                    # shadcn components
│   ├── Header.tsx
│   ├── Navigation.tsx
│   ├── Footer.tsx
│   ├── HelpButton.tsx
│   ├── ExperienceCard.tsx
│   ├── SkillSelector.tsx
│   ├── FileUpload.tsx
│   └── ProjectCard.tsx
├── pages/
│   ├── ProjectNew.tsx         # /project/new
│   ├── MyProjects.tsx         # /my-projects
│   └── Projects.tsx           # /projects (bonus)
├── hooks/
│   └── useForm.ts
├── types/
│   └── index.ts
├── lib/
│   └── utils.ts
├── App.tsx
└── main.tsx
```

## 6. Package Installation

```bash
# Already included in shadcn init
# Additional if needed:
npm install lucide-react
```

## 7. Route Configuration

| Route | Component | Description |
|-------|-----------|-------------|
| / | ProjectNew | Default to new project |
| /project/new | ProjectNew | Create new project |
| /my-projects | MyProjects | User's projects list |
| /projects | Projects | Public projects search |

## 8. Type Definitions

```typescript
// types/index.ts

export interface Project {
  id: string;
  title: string;
  category: string;
  level: 'Iniciante' | 'Intermediário' | 'Especialista';
  publishedAt: string;
  timeRemaining: string;
  proposals: number;
  interested: number;
  description: string;
  client: {
    name: string;
    rating: number;
    reviews: number;
  };
  tags?: string[];
  isFeatured?: boolean;
}

export interface ProjectFormData {
  category: string;
  name: string;
  description: string;
  files: File[];
  skills: string[];
  experienceLevel: 'Iniciante' | 'Intermediário' | 'Especialista';
  proposalDays: number;
  visibility: 'public' | 'private';
}
```

## 9. Form Validation

| Field | Validation |
|-------|------------|
| category | Required |
| name | Required, max 75 chars |
| description | Required, max 5000 chars |
| skills | Max 5 items |
| experienceLevel | Required |
| proposalDays | Required |
| visibility | Required |
