import React from 'react';
import { Star } from 'lucide-react';

interface StarRatingProps {
  rating: number;
  reviewCount: number;
}

export const StarRating: React.FC<StarRatingProps> = ({ rating, reviewCount }) => {
  const fullStars = Math.floor(rating);
  const hasHalfStar = rating % 1 >= 0.5;
  const emptyStars = 5 - fullStars - (hasHalfStar ? 1 : 0);

  return (
    <div className="flex items-center gap-1">
      <div className="flex items-center">
        {/* Full stars */}
        {Array.from({ length: fullStars }).map((_, i) => (
          <Star
            key={`full-${i}`}
            className="w-3.5 h-3.5 fill-freelas-gold text-freelas-gold"
          />
        ))}
        {/* Half star */}
        {hasHalfStar && (
          <div className="relative w-3.5 h-3.5">
            <Star className="absolute w-3.5 h-3.5 text-gray-300" />
            <div className="absolute overflow-hidden w-1/2">
              <Star className="w-3.5 h-3.5 fill-freelas-gold text-freelas-gold" />
            </div>
          </div>
        )}
        {/* Empty stars */}
        {Array.from({ length: emptyStars }).map((_, i) => (
          <Star
            key={`empty-${i}`}
            className="w-3.5 h-3.5 text-gray-300"
          />
        ))}
      </div>
      <span className="text-xs text-freelas-text-muted">
        ({reviewCount} avaliações)
      </span>
    </div>
  );
};
