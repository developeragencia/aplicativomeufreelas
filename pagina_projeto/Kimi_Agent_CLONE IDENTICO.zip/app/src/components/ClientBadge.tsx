import React from 'react';
import { Medal } from 'lucide-react';

interface ClientBadgeProps {
  level: 'none' | 'prata' | 'ouro' | 'platina';
}

export const ClientBadge: React.FC<ClientBadgeProps> = ({ level }) => {
  if (level === 'none') return null;

  const config = {
    prata: {
      color: 'text-freelas-silver',
      bgColor: 'bg-gray-100',
      label: 'Prata',
    },
    ouro: {
      color: 'text-yellow-600',
      bgColor: 'bg-yellow-50',
      label: 'Ouro',
    },
    platina: {
      color: 'text-gray-500',
      bgColor: 'bg-gray-50',
      label: 'Platina',
    },
  };

  const { color, bgColor, label } = config[level];

  return (
    <span className={`inline-flex items-center gap-1 px-2 py-0.5 text-xs font-medium ${color} ${bgColor} rounded`}>
      <Medal className={`w-3 h-3 ${color}`} />
      Nível {label}
    </span>
  );
};
