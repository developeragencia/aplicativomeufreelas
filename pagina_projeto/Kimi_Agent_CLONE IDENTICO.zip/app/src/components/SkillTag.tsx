import React from 'react';

interface SkillTagProps {
  name: string;
}

export const SkillTag: React.FC<SkillTagProps> = ({ name }) => {
  return (
    <span className="inline-flex items-center px-2 py-1 text-xs font-normal text-freelas-text-secondary bg-freelas-border-light rounded">
      {name}
    </span>
  );
};
