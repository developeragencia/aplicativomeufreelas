import React, { useState } from 'react';
import { Bookmark } from 'lucide-react';
import type { Job } from '@/types';
import { SkillTag } from './SkillTag';
import { StarRating } from './StarRating';
import { ClientBadge } from './ClientBadge';

interface JobCardProps {
  job: Job;
  index?: number;
}

export const JobCard: React.FC<JobCardProps> = ({ job, index = 0 }) => {
  const [isBookmarked, setIsBookmarked] = useState(job.isBookmarked || false);

  const handleBookmarkClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    setIsBookmarked(!isBookmarked);
  };

  return (
    <div
      className="bg-white border border-freelas-border rounded p-4 hover:shadow-card-hover hover:-translate-y-0.5 transition-all duration-200 cursor-pointer animate-fade-in-up"
      style={{ animationDelay: `${index * 0.05}s` }}
    >
      {/* Header: Title + Bookmark */}
      <div className="flex items-start justify-between gap-4 mb-2">
        <h3 className="text-base font-semibold text-freelas-primary hover:underline line-clamp-2">
          {job.title}
        </h3>
        <button
          onClick={handleBookmarkClick}
          className="flex-shrink-0 p-1 hover:bg-gray-100 rounded transition-colors duration-200"
          aria-label={isBookmarked ? 'Remover dos favoritos' : 'Adicionar aos favoritos'}
        >
          <Bookmark
            className={`w-5 h-5 transition-colors duration-200 ${
              isBookmarked
                ? 'fill-freelas-primary text-freelas-primary'
                : 'text-freelas-text-muted hover:text-freelas-primary'
            }`}
          />
        </button>
      </div>

      {/* Client Info */}
      <div className="flex items-center gap-3 mb-3">
        <ClientBadge level={job.client.level} />
        <StarRating
          rating={job.client.rating}
          reviewCount={job.client.reviewCount}
        />
      </div>

      {/* Description */}
      <p className="text-sm text-freelas-text-secondary line-clamp-3 mb-3">
        {job.description}
      </p>

      {/* Skills */}
      <div className="flex flex-wrap gap-2 mb-4">
        {job.skills.map((skill, i) => (
          <SkillTag key={i} name={skill} />
        ))}
      </div>

      {/* Footer: Proposals + Time */}
      <div className="flex items-center justify-between pt-3 border-t border-freelas-border-light">
        <span className="text-sm font-semibold text-freelas-success">
          {job.proposals} propostas
        </span>
        <span className="text-xs text-freelas-text-muted">
          Publicado há {job.publishedAt}
        </span>
      </div>
    </div>
  );
};
