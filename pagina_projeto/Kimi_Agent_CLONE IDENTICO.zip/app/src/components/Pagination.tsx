import React from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';

interface PaginationProps {
  currentPage: number;
  totalPages: number;
  onPageChange?: (page: number) => void;
}

export const Pagination: React.FC<PaginationProps> = ({
  currentPage,
  totalPages,
  onPageChange,
}) => {
  const handlePageChange = (page: number) => {
    if (page >= 1 && page <= totalPages && onPageChange) {
      onPageChange(page);
    }
  };

  const getPageNumbers = () => {
    const pages: (number | string)[] = [];
    
    if (totalPages <= 5) {
      for (let i = 1; i <= totalPages; i++) {
        pages.push(i);
      }
    } else {
      if (currentPage <= 3) {
        pages.push(1, 2, 3, '...', totalPages);
      } else if (currentPage >= totalPages - 2) {
        pages.push(1, '...', totalPages - 2, totalPages - 1, totalPages);
      } else {
        pages.push(1, '...', currentPage, '...', totalPages);
      }
    }
    
    return pages;
  };

  return (
    <div className="flex items-center justify-center gap-2 py-6">
      {/* Previous Button */}
      <button
        onClick={() => handlePageChange(currentPage - 1)}
        disabled={currentPage === 1}
        className={`flex items-center gap-1 px-3 py-2 text-sm font-medium rounded transition-colors duration-200 ${
          currentPage === 1
            ? 'text-freelas-text-muted cursor-not-allowed'
            : 'text-freelas-text-secondary hover:bg-gray-100 hover:text-freelas-text'
        }`}
      >
        <ChevronLeft className="w-4 h-4" />
        <span className="hidden sm:inline">Anterior</span>
      </button>

      {/* Page Numbers */}
      <div className="flex items-center gap-1">
        {getPageNumbers().map((page, index) => (
          <React.Fragment key={index}>
            {page === '...' ? (
              <span className="px-3 py-2 text-sm text-freelas-text-muted">
                ...
              </span>
            ) : (
              <button
                onClick={() => handlePageChange(page as number)}
                className={`min-w-[36px] h-9 px-3 text-sm font-medium rounded transition-colors duration-200 ${
                  currentPage === page
                    ? 'bg-freelas-primary text-white'
                    : 'text-freelas-text-secondary hover:bg-gray-100 hover:text-freelas-text'
                }`}
              >
                {page}
              </button>
            )}
          </React.Fragment>
        ))}
      </div>

      {/* Next Button */}
      <button
        onClick={() => handlePageChange(currentPage + 1)}
        disabled={currentPage === totalPages}
        className={`flex items-center gap-1 px-3 py-2 text-sm font-medium rounded transition-colors duration-200 ${
          currentPage === totalPages
            ? 'text-freelas-text-muted cursor-not-allowed'
            : 'text-freelas-text-secondary hover:bg-gray-100 hover:text-freelas-text'
        }`}
      >
        <span className="hidden sm:inline">Próximo</span>
        <ChevronRight className="w-4 h-4" />
      </button>

      {/* Page Indicator */}
      <span className="ml-4 text-sm text-freelas-text-muted">
        {currentPage} de {totalPages}
      </span>
    </div>
  );
};
