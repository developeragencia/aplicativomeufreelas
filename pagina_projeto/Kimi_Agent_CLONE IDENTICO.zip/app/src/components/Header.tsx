import React, { useState } from 'react';
import { Search, Bell, MessageSquare, User, Menu, X } from 'lucide-react';

export const Header: React.FC = () => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [searchValue, setSearchValue] = useState('');

  const navLinks = [
    { name: 'Projetos', href: '#', active: true },
    { name: 'Concorrentes', href: '#' },
    { name: 'Profissionais', href: '#' },
  ];

  return (
    <header className="sticky top-0 z-50 bg-freelas-primary shadow-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-14">
          {/* Logo */}
          <div className="flex items-center flex-shrink-0">
            <a href="/" className="flex items-center">
              <span className="text-2xl font-bold text-white">
                <span className="italic">99</span>freelas
              </span>
            </a>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-6 ml-8">
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                className={`text-sm font-medium text-white transition-opacity duration-200 ${
                  link.active ? 'opacity-100' : 'opacity-80 hover:opacity-100'
                }`}
              >
                {link.name}
              </a>
            ))}
          </nav>

          {/* Search Bar - Desktop */}
          <div className="hidden md:flex flex-1 max-w-md mx-8">
            <div className="relative w-full">
              <input
                type="text"
                placeholder="Palavras-chave"
                value={searchValue}
                onChange={(e) => setSearchValue(e.target.value)}
                className="w-full h-9 pl-10 pr-4 text-sm text-freelas-text bg-white border-0 rounded focus:outline-none focus:ring-2 focus:ring-white/30 transition-shadow duration-200"
              />
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-freelas-text-muted" />
            </div>
          </div>

          {/* Right Icons */}
          <div className="flex items-center space-x-2">
            <button className="hidden md:flex p-2 text-white opacity-80 hover:opacity-100 hover:scale-110 transition-all duration-200">
              <Bell className="w-5 h-5" />
            </button>
            <button className="hidden md:flex p-2 text-white opacity-80 hover:opacity-100 hover:scale-110 transition-all duration-200">
              <MessageSquare className="w-5 h-5" />
            </button>
            <button className="flex p-2 text-white opacity-80 hover:opacity-100 hover:scale-110 transition-all duration-200">
              <User className="w-5 h-5" />
            </button>

            {/* Mobile Menu Button */}
            <button
              className="md:hidden p-2 text-white"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            >
              {isMobileMenuOpen ? (
                <X className="w-6 h-6" />
              ) : (
                <Menu className="w-6 h-6" />
              )}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        {isMobileMenuOpen && (
          <div className="md:hidden py-4 border-t border-white/20">
            {/* Mobile Search */}
            <div className="mb-4">
              <div className="relative">
                <input
                  type="text"
                  placeholder="Palavras-chave"
                  value={searchValue}
                  onChange={(e) => setSearchValue(e.target.value)}
                  className="w-full h-10 pl-10 pr-4 text-sm text-freelas-text bg-white border-0 rounded focus:outline-none"
                />
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-freelas-text-muted" />
              </div>
            </div>

            {/* Mobile Nav Links */}
            <nav className="space-y-2">
              {navLinks.map((link) => (
                <a
                  key={link.name}
                  href={link.href}
                  className="block px-3 py-2 text-sm font-medium text-white opacity-80 hover:opacity-100 hover:bg-white/10 rounded transition-colors duration-200"
                >
                  {link.name}
                </a>
              ))}
            </nav>
          </div>
        )}
      </div>
    </header>
  );
};
