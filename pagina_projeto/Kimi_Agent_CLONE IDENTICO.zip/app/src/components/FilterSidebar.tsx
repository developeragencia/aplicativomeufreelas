import React, { useState } from 'react';
import { Plus, X } from 'lucide-react';
import { Checkbox } from '@/components/ui/checkbox';
import { Button } from '@/components/ui/button';
import { FilterSection } from './FilterSection';
import { categories, projectTypes, dateFilters, clientRankings, experienceLevels } from '@/data/jobs';

interface FilterSidebarProps {
  onFilterChange?: (filters: any) => void;
}

export const FilterSidebar: React.FC<FilterSidebarProps> = ({ onFilterChange: _onFilterChange }) => {
  const [keywords, setKeywords] = useState<string[]>([]);
  const [newKeyword, setNewKeyword] = useState('');
  const [selectedCategories, setSelectedCategories] = useState<string[]>([]);
  const [selectedProjectType, setSelectedProjectType] = useState<string>('all');
  const [selectedDate, setSelectedDate] = useState<string>('any');
  const [selectedRankings, setSelectedRankings] = useState<string[]>([]);
  const [selectedLevels, setSelectedLevels] = useState<string[]>([]);
  const [urgentOnly, setUrgentOnly] = useState(false);
  const [companiesOnly, setCompaniesOnly] = useState(false);

  const handleAddKeyword = () => {
    if (newKeyword.trim() && !keywords.includes(newKeyword.trim())) {
      setKeywords([...keywords, newKeyword.trim()]);
      setNewKeyword('');
    }
  };

  const handleRemoveKeyword = (keyword: string) => {
    setKeywords(keywords.filter((k) => k !== keyword));
  };

  const handleCategoryChange = (category: string, checked: boolean) => {
    if (checked) {
      setSelectedCategories([...selectedCategories, category]);
    } else {
      setSelectedCategories(selectedCategories.filter((c) => c !== category));
    }
  };

  const handleRankingChange = (ranking: string, checked: boolean) => {
    if (checked) {
      setSelectedRankings([...selectedRankings, ranking]);
    } else {
      setSelectedRankings(selectedRankings.filter((r) => r !== ranking));
    }
  };

  const handleLevelChange = (level: string, checked: boolean) => {
    if (checked) {
      setSelectedLevels([...selectedLevels, level]);
    } else {
      setSelectedLevels(selectedLevels.filter((l) => l !== level));
    }
  };

  const handleClearFilters = () => {
    setKeywords([]);
    setSelectedCategories([]);
    setSelectedProjectType('all');
    setSelectedDate('any');
    setSelectedRankings([]);
    setSelectedLevels([]);
    setUrgentOnly(false);
    setCompaniesOnly(false);
  };

  const hasActiveFilters =
    keywords.length > 0 ||
    selectedCategories.length > 0 ||
    selectedProjectType !== 'all' ||
    selectedDate !== 'any' ||
    selectedRankings.length > 0 ||
    selectedLevels.length > 0 ||
    urgentOnly ||
    companiesOnly;

  return (
    <aside className="w-full lg:w-72 flex-shrink-0">
      <div className="bg-white border border-freelas-border rounded p-4 lg:sticky lg:top-20">
        {/* Meus Filtros */}
        <FilterSection title="Meus Filtros" defaultOpen={true}>
          <div className="text-sm text-freelas-text-muted">
            Não há filtros no momento
          </div>
          <button className="mt-2 text-sm text-freelas-primary hover:text-freelas-primary-dark hover:underline transition-colors duration-200">
            Criar alerta
          </button>
        </FilterSection>

        {/* Palavras-chave */}
        <FilterSection title="Palavras-chave" defaultOpen={true}>
          <div className="flex gap-2">
            <input
              type="text"
              value={newKeyword}
              onChange={(e) => setNewKeyword(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleAddKeyword()}
              placeholder="Adicionar..."
              className="flex-1 h-8 px-3 text-sm border border-freelas-border rounded focus:outline-none focus:border-freelas-primary transition-colors duration-200"
            />
            <button
              onClick={handleAddKeyword}
              className="flex items-center justify-center w-8 h-8 bg-freelas-primary text-white rounded hover:bg-freelas-primary-dark transition-colors duration-200"
            >
              <Plus className="w-4 h-4" />
            </button>
          </div>
          {keywords.length > 0 && (
            <div className="flex flex-wrap gap-2 mt-3">
              {keywords.map((keyword) => (
                <span
                  key={keyword}
                  className="inline-flex items-center gap-1 px-2 py-1 text-xs bg-freelas-primary-light text-freelas-primary rounded"
                >
                  {keyword}
                  <button
                    onClick={() => handleRemoveKeyword(keyword)}
                    className="hover:text-freelas-primary-dark"
                  >
                    <X className="w-3 h-3" />
                  </button>
                </span>
              ))}
            </div>
          )}
        </FilterSection>

        {/* Categorias */}
        <FilterSection title="Categorias" defaultOpen={true}>
          <div className="space-y-2 max-h-48 overflow-y-auto">
            {categories.map((category) => (
              <label
                key={category.name}
                className="flex items-center gap-2 cursor-pointer hover:bg-gray-50 p-1 rounded transition-colors duration-150"
              >
                <Checkbox
                  checked={selectedCategories.includes(category.name)}
                  onCheckedChange={(checked) =>
                    handleCategoryChange(category.name, checked as boolean)
                  }
                  className="border-freelas-border data-[state=checked]:bg-freelas-primary data-[state=checked]:border-freelas-primary"
                />
                <span className="text-sm text-freelas-text-secondary flex-1">
                  {category.name}
                </span>
                <span className="text-xs text-freelas-text-muted">
                  ({category.count})
                </span>
              </label>
            ))}
          </div>
        </FilterSection>

        {/* Tipo de projeto */}
        <FilterSection title="Tipo de projeto" defaultOpen={true}>
          <div className="space-y-2">
            {projectTypes.map((type) => (
              <label
                key={type.name}
                className="flex items-center gap-2 cursor-pointer hover:bg-gray-50 p-1 rounded transition-colors duration-150"
              >
                <input
                  type="radio"
                  name="projectType"
                  checked={selectedProjectType === type.name.toLowerCase()}
                  onChange={() => setSelectedProjectType(type.name.toLowerCase())}
                  className="w-4 h-4 text-freelas-primary border-freelas-border focus:ring-freelas-primary"
                />
                <span className="text-sm text-freelas-text-secondary flex-1">
                  {type.name}
                </span>
                <span className="text-xs text-freelas-text-muted">
                  ({type.count})
                </span>
              </label>
            ))}
          </div>
        </FilterSection>

        {/* Data de publicação */}
        <FilterSection title="Data de publicação" defaultOpen={false}>
          <div className="space-y-2">
            {dateFilters.map((filter) => (
              <label
                key={filter.value}
                className="flex items-center gap-2 cursor-pointer hover:bg-gray-50 p-1 rounded transition-colors duration-150"
              >
                <input
                  type="radio"
                  name="datePosted"
                  checked={selectedDate === filter.value}
                  onChange={() => setSelectedDate(filter.value)}
                  className="w-4 h-4 text-freelas-primary border-freelas-border focus:ring-freelas-primary"
                />
                <span className="text-sm text-freelas-text-secondary">
                  {filter.name}
                </span>
              </label>
            ))}
          </div>
        </FilterSection>

        {/* Ranking do cliente */}
        <FilterSection title="Ranking do cliente" defaultOpen={false}>
          <div className="space-y-2">
            {clientRankings.map((ranking) => (
              <label
                key={ranking.value}
                className="flex items-center gap-2 cursor-pointer hover:bg-gray-50 p-1 rounded transition-colors duration-150"
              >
                <Checkbox
                  checked={selectedRankings.includes(ranking.value)}
                  onCheckedChange={(checked) =>
                    handleRankingChange(ranking.value, checked as boolean)
                  }
                  className="border-freelas-border data-[state=checked]:bg-freelas-primary data-[state=checked]:border-freelas-primary"
                />
                <span className="text-sm text-freelas-text-secondary">
                  {ranking.name}
                </span>
              </label>
            ))}
          </div>
        </FilterSection>

        {/* Nível de experiência */}
        <FilterSection title="Nível de experiência" defaultOpen={false}>
          <div className="space-y-2">
            {experienceLevels.map((level) => (
              <label
                key={level.value}
                className="flex items-center gap-2 cursor-pointer hover:bg-gray-50 p-1 rounded transition-colors duration-150"
              >
                <Checkbox
                  checked={selectedLevels.includes(level.value)}
                  onCheckedChange={(checked) =>
                    handleLevelChange(level.value, checked as boolean)
                  }
                  className="border-freelas-border data-[state=checked]:bg-freelas-primary data-[state=checked]:border-freelas-primary"
                />
                <span className="text-sm text-freelas-text-secondary">
                  {level.name}
                </span>
              </label>
            ))}
          </div>
        </FilterSection>

        {/* Outros Filtros */}
        <FilterSection title="Outros Filtros" defaultOpen={false}>
          <div className="space-y-2">
            <label className="flex items-center gap-2 cursor-pointer hover:bg-gray-50 p-1 rounded transition-colors duration-150">
              <Checkbox
                checked={urgentOnly}
                onCheckedChange={(checked) => setUrgentOnly(checked as boolean)}
                className="border-freelas-border data-[state=checked]:bg-freelas-primary data-[state=checked]:border-freelas-primary"
              />
              <span className="text-sm text-freelas-text-secondary">
                Projetos Urgentes
              </span>
            </label>
            <label className="flex items-center gap-2 cursor-pointer hover:bg-gray-50 p-1 rounded transition-colors duration-150">
              <Checkbox
                checked={companiesOnly}
                onCheckedChange={(checked) => setCompaniesOnly(checked as boolean)}
                className="border-freelas-border data-[state=checked]:bg-freelas-primary data-[state=checked]:border-freelas-primary"
              />
              <span className="text-sm text-freelas-text-secondary">
                Para Empresas
              </span>
            </label>
          </div>
        </FilterSection>

        {/* Limpar Filtros */}
        {hasActiveFilters && (
          <div className="pt-4 mt-4 border-t border-freelas-border-light">
            <Button
              onClick={handleClearFilters}
              variant="outline"
              className="w-full text-freelas-primary border-freelas-primary hover:bg-freelas-primary-light"
            >
              Limpar Filtros
            </Button>
          </div>
        )}
      </div>
    </aside>
  );
};
