import React, { useState } from 'react';
import { ChevronDown, ChevronUp } from 'lucide-react';

interface FilterSectionProps {
  title: string;
  children: React.ReactNode;
  defaultOpen?: boolean;
}

export const FilterSection: React.FC<FilterSectionProps> = ({
  title,
  children,
  defaultOpen = true,
}) => {
  const [isOpen, setIsOpen] = useState(defaultOpen);

  return (
    <div className="border-b border-freelas-border-light last:border-b-0">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center justify-between w-full py-3 text-left hover:bg-gray-50 transition-colors duration-150"
      >
        <span className="text-sm font-semibold text-freelas-text uppercase tracking-wide">
          {title}
        </span>
        {isOpen ? (
          <ChevronUp className="w-4 h-4 text-freelas-text-muted" />
        ) : (
          <ChevronDown className="w-4 h-4 text-freelas-text-muted" />
        )}
      </button>
      <div
        className={`overflow-hidden transition-all duration-200 ${
          isOpen ? 'max-h-96 pb-4' : 'max-h-0'
        }`}
      >
        {children}
      </div>
    </div>
  );
};
