import React from 'react';
import { HelpCircle } from 'lucide-react';

export const HelpButton: React.FC = () => {
  return (
    <button
      className="fixed bottom-6 right-6 z-50 flex items-center gap-2 px-5 py-3 bg-freelas-primary text-white font-semibold rounded-full shadow-lg hover:bg-freelas-primary-dark hover:scale-105 active:scale-95 transition-all duration-200"
      onClick={() => {
        // Help action
        alert('Central de Ajuda - Em breve!');
      }}
    >
      <HelpCircle className="w-5 h-5" />
      <span>Ajuda</span>
    </button>
  );
};
