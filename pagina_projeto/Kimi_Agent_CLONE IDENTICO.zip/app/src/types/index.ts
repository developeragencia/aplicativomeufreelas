export interface Client {
  name: string;
  level: 'none' | 'prata' | 'ouro' | 'platina';
  rating: number;
  reviewCount: number;
}

export interface Job {
  id: string;
  title: string;
  client: Client;
  description: string;
  skills: string[];
  proposals: number;
  publishedAt: string;
  isUrgent?: boolean;
  isBookmarked?: boolean;
}

export interface FilterState {
  keywords: string[];
  categories: string[];
  projectType: 'all' | 'projeto' | 'concurso';
  datePosted: 'any' | '24h' | '3d' | '7d';
  clientRanking: ('none' | 'prata' | 'ouro' | 'platina')[];
  experienceLevel: ('basico' | 'intermediario' | 'avancado')[];
  urgentOnly: boolean;
  companiesOnly: boolean;
}

export interface Category {
  name: string;
  count: number;
}
