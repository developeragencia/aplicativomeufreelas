import { useState } from 'react';
import { SlidersHorizontal } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Header } from '@/components/Header';
import { FilterSidebar } from '@/components/FilterSidebar';
import { JobCard } from '@/components/JobCard';
import { Pagination } from '@/components/Pagination';
import { HelpButton } from '@/components/HelpButton';
import { Footer } from '@/components/Footer';
import { jobs } from '@/data/jobs';

function App() {
  const [currentPage, setCurrentPage] = useState(1);
  const [isMobileFilterOpen, setIsMobileFilterOpen] = useState(false);
  const totalPages = 2;
  const totalResults = 1801;

  const handlePageChange = (page: number) => {
    setCurrentPage(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-freelas-bg">
      {/* Header */}
      <Header />

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {/* Page Title Section */}
        <div className="bg-white border border-freelas-border rounded p-4 sm:p-6 mb-6">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div>
              <h1 className="text-xl sm:text-2xl font-bold text-freelas-text mb-1">
                Resultado da pesquisa
              </h1>
              <p className="text-sm text-freelas-text-secondary">
                {totalResults.toLocaleString()} opções encontradas
              </p>
            </div>
            <div className="flex items-center gap-3">
              {/* Mobile Filter Toggle */}
              <Button
                variant="outline"
                className="lg:hidden flex items-center gap-2"
                onClick={() => setIsMobileFilterOpen(!isMobileFilterOpen)}
              >
                <SlidersHorizontal className="w-4 h-4" />
                Filtros
              </Button>
              <Button className="bg-freelas-primary hover:bg-freelas-primary-dark text-white">
                Receber novidades 1 vez
              </Button>
            </div>
          </div>
        </div>

        {/* Content Layout */}
        <div className="flex flex-col lg:flex-row gap-6">
          {/* Filter Sidebar - Desktop */}
          <div className="hidden lg:block">
            <FilterSidebar />
          </div>

          {/* Filter Sidebar - Mobile */}
          {isMobileFilterOpen && (
            <div className="lg:hidden">
              <FilterSidebar />
            </div>
          )}

          {/* Job Listings */}
          <div className="flex-1">
            <div className="space-y-4">
              {jobs.map((job, index) => (
                <JobCard key={job.id} job={job} index={index} />
              ))}
            </div>

            {/* Pagination */}
            <Pagination
              currentPage={currentPage}
              totalPages={totalPages}
              onPageChange={handlePageChange}
            />
          </div>
        </div>
      </main>

      {/* Footer */}
      <Footer />

      {/* Help Button */}
      <HelpButton />
    </div>
  );
}

export default App;
