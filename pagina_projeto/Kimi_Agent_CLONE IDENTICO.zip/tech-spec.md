# 99freelas Website - Technical Specification

## 1. Tech Stack Overview

| Category | Technology |
|----------|------------|
| Framework | React 18 + TypeScript |
| Build Tool | Vite |
| Styling | Tailwind CSS 3.4 |
| UI Components | shadcn/ui |
| Icons | Lucide React |
| State Management | React useState/useContext |
| Animation | CSS Transitions + Tailwind |

## 2. Tailwind Configuration Extensions

```javascript
// tailwind.config.js extensions
{
  theme: {
    extend: {
      colors: {
        primary: {
          DEFAULT: '#0099CC',
          dark: '#0077AA',
          light: '#E6F7FC',
        },
        surface: '#FFFFFF',
        background: '#F5F5F5',
        border: '#DDDDDD',
        'border-light': '#EEEEEE',
        'text-primary': '#333333',
        'text-secondary': '#666666',
        'text-muted': '#999999',
        success: '#28A745',
        gold: '#FFD700',
        silver: '#C0C0C0',
        platinum: '#E5E4E2',
      },
      fontFamily: {
        sans: ['Arial', 'Helvetica', 'sans-serif'],
      },
      fontSize: {
        'xs': '12px',
        'sm': '13px',
        'base': '14px',
        'lg': '16px',
        'xl': '18px',
        '2xl': '24px',
      },
      spacing: {
        '18': '4.5rem',
        '22': '5.5rem',
      },
      boxShadow: {
        'card': '0 2px 8px rgba(0, 0, 0, 0.1)',
        'card-hover': '0 4px 12px rgba(0, 0, 0, 0.15)',
      },
    },
  },
}
```

## 3. Component Inventory

### Shadcn/UI Components (Pre-installed)

| Component | Usage | Customization |
|-----------|-------|---------------|
| Button | Primary/Secondary actions | Custom colors, sizes |
| Checkbox | Filter selections | Custom check color |
| Input | Search, keyword input | Border radius, focus state |
| Badge | Skill tags, client levels | Custom colors per level |
| Card | Job listing containers | Custom border, shadow |
| Separator | Section dividers | Custom color |
| ScrollArea | Filter sidebar | Custom scrollbar |

### Custom Components

| Component | Props Interface | Description |
|-----------|-----------------|-------------|
| Header | - | Main navigation header |
| SearchBar | `placeholder: string, onSearch: fn` | Search input with icon |
| FilterSidebar | `filters: FilterState, onChange: fn` | Left sidebar filters |
| FilterSection | `title: string, children: ReactNode` | Collapsible filter group |
| JobCard | `job: Job` | Individual job listing |
| StarRating | `rating: number, count: number` | Star rating display |
| ClientBadge | `level: 'prata' \| 'ouro' \| 'platina'` | Client ranking badge |
| SkillTag | `name: string` | Skill pill tag |
| Pagination | `current: number, total: number, onChange: fn` | Page navigation |
| HelpButton | - | Floating help button |
| Footer | - | Page footer |

### Type Definitions

```typescript
// types/index.ts

interface Job {
  id: string;
  title: string;
  client: {
    name: string;
    level: 'none' | 'prata' | 'ouro' | 'platina';
    rating: number;
    reviewCount: number;
  };
  description: string;
  skills: string[];
  proposals: number;
  publishedAt: string;
  isUrgent?: boolean;
  isBookmarked?: boolean;
}

interface FilterState {
  keywords: string[];
  categories: string[];
  projectType: 'all' | 'projeto' | 'concurso';
  datePosted: 'any' | '24h' | '3d' | '7d';
  clientRanking: ('none' | 'prata' | 'ouro' | 'platina')[];
  experienceLevel: ('basico' | 'intermediario' | 'avancado')[];
  urgentOnly: boolean;
  companiesOnly: boolean;
}
```

## 4. Animation Implementation Plan

| Interaction Name | Tech Choice | Implementation Logic |
|------------------|-------------|---------------------|
| Card Hover Lift | Tailwind | `hover:shadow-card-hover hover:-translate-y-0.5 transition-all duration-200` |
| Card Stagger Load | CSS + React | `animation-delay` based on index, fade-in + translateY |
| Button Hover | Tailwind | `hover:bg-primary-dark transition-colors duration-200` |
| Link Hover | Tailwind | `hover:text-primary-dark transition-colors duration-200` |
| Checkbox Check | CSS | Native checkbox with custom styled checkmark |
| Filter Expand | CSS | `max-height` transition with overflow-hidden |
| Bookmark Toggle | React State | Color change on click, local state management |
| Page Transition | CSS | Fade in on mount with opacity transition |
| Help Button Hover | Tailwind | `hover:scale-105 transition-transform duration-200` |
| Search Focus | Tailwind | `focus:ring-2 focus:ring-primary-light transition-shadow` |

## 5. Project File Structure

```
/mnt/okcomputer/output/app/
├── src/
│   ├── components/
│   │   ├── ui/              # shadcn/ui components
│   │   ├── Header.tsx
│   │   ├── SearchBar.tsx
│   │   ├── FilterSidebar.tsx
│   │   ├── FilterSection.tsx
│   │   ├── JobCard.tsx
│   │   ├── StarRating.tsx
│   │   ├── ClientBadge.tsx
│   │   ├── SkillTag.tsx
│   │   ├── Pagination.tsx
│   │   ├── HelpButton.tsx
│   │   └── Footer.tsx
│   ├── types/
│   │   └── index.ts
│   ├── data/
│   │   └── jobs.ts          # Mock job data
│   ├── hooks/
│   │   └── useFilters.ts    # Filter state management
│   ├── App.tsx
│   ├── main.tsx
│   └── index.css
├── public/
├── index.html
├── tailwind.config.js
├── vite.config.ts
└── package.json
```

## 6. Package Installation Commands

```bash
# Initialize project (already includes shadcn/ui)
bash /app/.kimi/skills/webapp-building/scripts/init-webapp.sh "99freelas"

# Navigate to project
cd /mnt/okcomputer/output/app

# Install Lucide icons
npm install lucide-react

# No additional packages needed - shadcn/ui components are pre-installed
```

## 7. Implementation Order

1. **Setup**: Initialize project, configure Tailwind colors
2. **Types**: Create TypeScript interfaces
3. **Mock Data**: Create job listings data
4. **Components (Bottom-up)**:
   - SkillTag, StarRating, ClientBadge (atomic)
   - JobCard (composite)
   - FilterSection, FilterSidebar
   - SearchBar, Header
   - Pagination, HelpButton, Footer
5. **App Integration**: Compose all components in App.tsx
6. **Polish**: Add animations, verify responsiveness
7. **Build**: Production build and deploy

## 8. Responsive Breakpoints

| Breakpoint | Width | Layout Changes |
|------------|-------|----------------|
| Mobile | < 640px | Single column, hidden sidebar, stacked cards |
| Tablet | 640-1024px | Two columns, collapsible sidebar |
| Desktop | > 1024px | Full layout, sticky sidebar |

## 9. Performance Considerations

- Use `React.memo` for JobCard to prevent unnecessary re-renders
- Lazy load filter sidebar on mobile
- Use CSS transitions instead of JS animations
- Implement virtual scrolling if job list exceeds 50 items
